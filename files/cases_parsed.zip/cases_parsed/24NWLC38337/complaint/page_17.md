Exhibit C

<!-- PageBreak -->

