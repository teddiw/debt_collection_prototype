
<table>
<tr>
<th>Field</th>
<th>Field Data</th>
</tr>
<tr>
<td>Account Number</td>
<td>00 5691</td>
</tr>
<tr>
<td>Seller Account ID</td>
<td>8543</td>
</tr>
<tr>
<td>First Name</td>
<td>GABRIEL</td>
</tr>
<tr>
<td>Middle Name</td>
<td>A</td>
</tr>
<tr>
<td>Last Name</td>
<td>OGHENEKOHWO</td>
</tr>
<tr>
<td>SSN</td>
<td>XXX-XX-8967</td>
</tr>
<tr>
<td>Date of Birth</td>
<td></td>
</tr>
<tr>
<td>Address 1</td>
<td>9818 S 11TH AVE</td>
</tr>
<tr>
<td>City</td>
<td>INGLEWOOD</td>
</tr>
<tr>
<td>State</td>
<td>CA</td>
</tr>
<tr>
<td>Zip</td>
<td>90305</td>
</tr>
<tr>
<td>Home Phone</td>
<td>3237787893</td>
</tr>
<tr>
<td>Open Date</td>
<td>01/27/2020</td>
</tr>
<tr>
<td>Last Purchase Date</td>
<td>01/29/2020</td>
</tr>
<tr>
<td>Last Purchase Amount</td>
<td>$13,500.00</td>
</tr>
<tr>
<td>Last Payment Date</td>
<td>02/04/2021</td>
</tr>
<tr>
<td>Last Payment Amount</td>
<td>$240.00</td>
</tr>
<tr>
<td>Sale Amount</td>
<td>$16,307.28</td>
</tr>
<tr>
<td>Charge Off Date</td>
<td>09/30/2021</td>
</tr>
<tr>
<td>Charge off Balance</td>
<td>$16,307.28</td>
</tr>
<tr>
<td>Post Charge Off Interest</td>
<td>$0.00</td>
</tr>
<tr>
<td>Post Charge off Fee</td>
<td>$0.00</td>
</tr>
<tr>
<td>Post Charge off Payments</td>
<td>$0.00</td>
</tr>
<tr>
<td>Post Charge off Payments and Credits</td>
<td>$0.00</td>
</tr>
<tr>
<td>Post Charge off Credits</td>
<td>$0.00</td>
</tr>
<tr>
<td>Affinity</td>
<td>APLHAEON</td>
</tr>
<tr>
<td>Alternate Account #1</td>
<td>00 5691</td>
</tr>
</table>


Account information provided by Comenity Capital Bank pursuant to the Bill of Sale/Assignment of
Accounts transferred on or about 12/28/2022 in connection with the sale of accounts from Comenity
Capital Bank to Midland Credit Management, Inc.

MCMG_BULK_DEC_2022_DPL_CCB.TXT; MCMG_BULK_DEC_2022_LCS_CCB.TXT

<!-- PageBreak -->

