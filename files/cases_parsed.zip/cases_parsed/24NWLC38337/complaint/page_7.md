
# SCHEDULE 1 TO BILL OF SALE ASSET SCHEDULE

The individual Accounts transferred pursuant to the Credit Card Account Purchase Agreement and
Bill of Sale are described in the electronic file named
MCMG_BULK_DEC_2022_DPL_CCB.TXT; MCMG_BULK_DEC_2022_LCS_CCB.TXT
delivered by Comenity Capital Bank to MIDLAND CREDIT MANAGEMENT, INC. on
December 21, 2022, and summarized in the table immediately below (the "Sale File").


<table>
<tr>
<th>Lot</th>
<th>Sale ID</th>
<th># of Accounts</th>
<th>Aggregate Unpaid Balance</th>
<th>Purchase Price Percentage</th>
<th>File Creation Date</th>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td>12/21/2022</td>
</tr>
</table>


<!-- PageBreak -->

