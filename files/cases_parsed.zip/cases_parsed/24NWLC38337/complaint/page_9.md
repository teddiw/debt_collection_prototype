7\.
I certify under penalty of perjury that the foregoing is true and correct.

FURTHER AFFIANT SAYETH NOT.

Signed this
18th
day of January, 2023.

Bruce Sweeten

Bruce A. Sweeten (AFFIANT NAME)

Comenity Capital Bank


<figure>

Subscribed and sworn to before me Jennifer Pardue, on this
(date) day of January, in
the year 2023, by Bruce A. Sweeten, who proved on the basis of satisfactory evidence to be the
person whose name is subscribed to in this document.

(Notary's Official Seal)
Quindi Par due
Notary Signature

JENNIFER PARDUE
Notary Public - State of Utah
Comm. No. 718844
My Commission Expires on
Jun 17, 2025

</figure>


<!-- PageBreak -->

