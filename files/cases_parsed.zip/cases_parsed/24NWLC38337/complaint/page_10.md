
# CERTIFICATE OF CONFORMITY

STATE OF UTAH
COUNTY OF SALT LAKE

The undersigned does hereby certify that she/he is an attorney at law duly admitted to practice in
the State of Utah and is a resident of Utah, County of Salt Lake, Utah; that she/he is a person
duly qualified to make this certificate of conformity; that the foregoing acknowledgment by
Bruce A. Sweeten named in the foregoing instrument taken before Jennifer Pardue a notary in
the State of Utah duly conforms with the laws of the State of Utah, being the State in which it
was taken; and when executed by Mr. Sweeten in the manner indicated will qualify as a valid
and effective sworn statement in such state.

February 1, 2023

Date


<figure>

Jam DiFrom

Attorney at Law for the State of Utah

</figure>


<!-- PageBreak -->

