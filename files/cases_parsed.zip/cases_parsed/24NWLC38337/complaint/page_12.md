Exhibit B

<!-- PageBreak -->

