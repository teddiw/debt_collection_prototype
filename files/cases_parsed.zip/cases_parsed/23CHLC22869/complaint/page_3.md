13\. Demand has been made on Defendant(s), and each of them, for the payment of $9,339.79 due.


# FIRST CAUSE OF ACTION (Account Stated)

14\. Plaintiff refers to Paragraphs 1 through 14, and by this reference incorporates the same herein
as though fully set forth.

15\. Within the last four years, an account was stated by and between the charge off creditor and
Defendant(s), and each of them, wherein it stated that said Defendant(s), and each of them, were
indebted to the charge off creditor in the sum of $9,339.79. Plaintiff is the current holder and assignee
of the Account.


# SECOND CAUSE OF ACTION (Open Book Account)

16\. Plaintiff refers to Paragraphs 1 through 16, and by this reference incorporates the same herein
as though fully set forth.

17\. Within the last four years, Defendant(s), and each of them, became indebted to the charge-off
creditor on an open book account for $9,339.79 due. The open book account reflected all the credits
and debits involved in the financial transaction(s) between charge-off creditor and Defendant(s) in the
17 |Account. Plaintiff is the current holder and assignee of the Account.

<!-- PageFooter="COMPLAINT FOR MONEY" -->
<!-- PageNumber="3" -->

1
2
3
4
5
6
7
8
9
10
11
12

13
14
15
16
18
19
20
21
22
23
24
25
26
27
28

<!-- PageBreak -->

