
<figure>

usbank.

</figure>


November 2020 Statement
Open Date: 10/03/2020 Closing Date: 11/02/2020

U.S. Bank Platinum Visa® Card
DAVID L BARG


<table>
<tr>
<th></th>
<th>Page 1 of 3</th>
</tr>
<tr>
<td>Account:</td>
<td>2537</td>
</tr>
<tr>
<td>Cardmember Service</td>
<td>1-800-285-8585</td>
</tr>
<tr>
<td>BNK 25 US2 8</td>
<td>1</td>
</tr>
</table>


<table>
<tr>
<td>New Balance</td>
<td>$7,617.34</td>
</tr>
<tr>
<td>Minimum Payment Due</td>
<td>$218.00</td>
</tr>
<tr>
<td>Payment Due Date</td>
<td>11/28/2020</td>
</tr>
</table>


Late Payment Warning: If we do not receive your
minimum payment by the date listed above, you may have
to pay up to a $40.00 Late Fee

Minimum Payment Warning: If you make only the minimum
payment each period, you will pay more in interest and it will
take you longer to pay off your balance. For example:


<table>
<tr>
<th>If you make no additional charges using this card and each month you pay ...</th>
<th>You will pay off the balance shown on this statement in about ...</th>
<th>And you will end up paying an estimated total of ...</th>
</tr>
<tr>
<td>Only the minimum payment</td>
<td>13 years</td>
<td>$18,524</td>
</tr>
<tr>
<td>$293</td>
<td>3 years</td>
<td>$10,557 (Savings=$7,967)</td>
</tr>
</table>


If you would like information about credit counseling services,
call 866-951-1391.


<table>
<tr>
<td colspan="3">Activity Summary</td>
</tr>
<tr>
<td>Previous Balance</td>
<td>+</td>
<td>$7,039.72</td>
</tr>
<tr>
<td>Payments</td>
<td>-</td>
<td>$213.00CR</td>
</tr>
<tr>
<td>Other Credits</td>
<td></td>
<td>$0.00</td>
</tr>
<tr>
<td>Purchases</td>
<td>+</td>
<td>$647.69</td>
</tr>
<tr>
<td>Balance Transfers</td>
<td></td>
<td>$0.00</td>
</tr>
<tr>
<td>Advances</td>
<td></td>
<td>$0.00</td>
</tr>
<tr>
<td>Other Debits</td>
<td></td>
<td>$0.00</td>
</tr>
<tr>
<td>Fees Charged</td>
<td></td>
<td>$0.00</td>
</tr>
<tr>
<td>Interest Charged</td>
<td>+</td>
<td>$142.93</td>
</tr>
<tr>
<td>New Balance</td>
<td>=</td>
<td>$7,617.34</td>
</tr>
<tr>
<td>Past Due</td>
<td></td>
<td>$0.00</td>
</tr>
<tr>
<td>Minimum Payment Due</td>
<td></td>
<td>$218.00</td>
</tr>
<tr>
<td>Credit Line</td>
<td></td>
<td>$8,500.00</td>
</tr>
<tr>
<td>Available Credit</td>
<td></td>
<td>$882.66</td>
</tr>
<tr>
<td>Days in Billing Period</td>
<td></td>
<td>31</td>
</tr>
</table>


<figure>

Payment
Options:

POST

Mail payment coupon
with a check

Pay online at
usbank.com

Pay by phone
1-800-285-8585

Pay at your local
U.S. Bank branch

Please detach and send coupon with check payable to: U.S. Bank

usbank.

2537

24-Hour Cardmember Service: 1-800-285-8585
C
. to pay by phone
. to change your address

Amount Enclosed
$

000035431 01 SP
000638623163892 P Y

DAVID L BARG
3454 CARIBETH DR
ENCINO CA 91436-4102

U.S. Bank
P.O. Box 790408
St. Louis, MO 63179-0408

</figure>


<table>
<tr>
<td>Account Number</td>
<td>2537</td>
</tr>
<tr>
<td>Payment Due Date</td>
<td>11/28/2020</td>
</tr>
<tr>
<td>New Balance</td>
<td>$7,617.34</td>
</tr>
<tr>
<td>Minimum Payment Due</td>
<td>$218.00</td>
</tr>
</table>


<!-- PageBreak -->

