<!-- PageHeader="File TP126445" -->

EXHIBIT "B"

<!-- PageBreak -->

