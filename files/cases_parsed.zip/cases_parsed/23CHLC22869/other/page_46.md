<!-- PageNumber="/12915" -->

OriginalChargeoffAdditionalBalanceCategoryAmount19

[Redacted]
[Redacted]
[Redacted]
[Redacted]


### CurrentChargeoffAdditionalBalanceCategoryAmount19

[Redacted]
[Redacted]
[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]
[Redacted]
[Redacted]
[Redacted]
[Redacted]

[Redacted]
[Redacted]
[Redacted]

[Redacted]
0

[Redacted]
0
[Redacted]
[Redacted]
[Redacted]
[Redacted]

[Redacted]
[Redacted]
[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]
[Redacted]
[Redacted]
[Redacted]
[Redacted]

[Redacted]
[Redacted]
[Redacted]
[Redacted]
[Redacted]

<!-- PageBreak -->

