<!-- PageNumber="/12915" -->
<!-- PageNumber="." -->
<!-- PageNumber="-" -->

OriginalChargeoffAdditionalBalanceCategoryAmount13


### CurrentChargeofAdditionalBalanceCategoryAmount13

[Redacted]

[Redacted]
[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

0

[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]
[Redacted]
[Redacted]
[Redacted]
[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]
0
[Redacted]
[Redacted]
[Redacted]

<!-- PageBreak -->

