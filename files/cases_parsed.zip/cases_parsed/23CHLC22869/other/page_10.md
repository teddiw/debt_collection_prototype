/12915


<table>
<tr>
<th colspan="3">FileName</th>
<th>LineNumber</th>
<th>PoolNumber</th>
<th>AccountNumberPAN</th>
<th>PrimaryCustomerLastName</th>
<th>PrimaryCustomerFirstName</th>
</tr>
<tr>
<th>795 usb</th>
<th colspan="2">sale 20220621</th>
<th>2409</th>
<th>[Redacted]</th>
<th>[Redacted]8448</th>
<th>[Redacted]</th>
<th>[Redacted]</th>
</tr>
<tr>
<td>795 usb</td>
<td>sale</td>
<td>20220621</td>
<td>2410</td>
<td>[Redacted]</td>
<td>[Redacted]6250</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>795 usb</td>
<td colspan="2">sale 20220621</td>
<td>2411</td>
<td>[Redacted]</td>
<td>[Redacted]5649</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>795 usb</td>
<td colspan="2">sale 20220621</td>
<td>2412</td>
<td>[Redacted]</td>
<td>[Redacted]9202</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>795</td>
<td colspan="2">usb_sale 20220621</td>
<td>2413</td>
<td>[Redacted]</td>
<td>[Redacted]5808</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>795 usb</td>
<td colspan="2">sale 20220621</td>
<td>2414</td>
<td>[Redacted]</td>
<td>[Redacted]6193</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>795 usb</td>
<td>sale</td>
<td>20220621</td>
<td>2415</td>
<td>[Redacted]</td>
<td>[Redacted]0294</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>795 usb</td>
<td colspan="2">sale 20220621</td>
<td>2416</td>
<td>[Redacted]</td>
<td>[Redacted]7943</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>795 usb</td>
<td colspan="2">sale 20220621</td>
<td>2417</td>
<td>[Redacted]</td>
<td>[Redacted]1134</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>795 usb</td>
<td colspan="2">sale 20220621</td>
<td>2418</td>
<td>[Redacted]</td>
<td>[Redacted]0812</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>795_usb</td>
<td colspan="2">sale 20220621</td>
<td>2419</td>
<td>795</td>
<td>2537</td>
<td>BARG</td>
<td>DAVID</td>
</tr>
<tr>
<td>795 usb</td>
<td colspan="2">sale 20220621</td>
<td>2420</td>
<td>[Redacted]</td>
<td>[Redacted]6304</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>795_usb</td>
<td colspan="2">sale 20220621</td>
<td>2421</td>
<td>[Redacted]</td>
<td>[Redacted]6077</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>795 usb</td>
<td colspan="2">sale 20220621</td>
<td>2422</td>
<td>[Redacted]</td>
<td>[Redacted]8820</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>795 usb</td>
<td colspan="2">sale 20220621</td>
<td>2423</td>
<td>[Redacted]</td>
<td>[Redacted]5432</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>795 usb.</td>
<td colspan="2">sale 20220621</td>
<td>2424</td>
<td>[Redacted]</td>
<td>[Redacted]5095</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>795 usb</td>
<td colspan="2">sale 20220621</td>
<td>2425</td>
<td>[Redacted]</td>
<td>[Redacted]5598</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>795 usb</td>
<td colspan="2">sale 20220621</td>
<td>2426</td>
<td>[Redacted]</td>
<td>[Redacted]3253</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>795_usb</td>
<td colspan="2">sale 20220621</td>
<td>2427</td>
<td>[Redacted]</td>
<td>[Redacted]5704</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td></td>
<td colspan="2">795_usb_sale_20220621</td>
<td>2428</td>
<td>[Redacted]</td>
<td>[Redacted]8178</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>795 usb</td>
<td colspan="2">sale 20220621</td>
<td>2429</td>
<td>[Redacted]</td>
<td>[Redacted]8529</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
</table>


<!-- PageBreak -->

