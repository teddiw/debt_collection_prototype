
<figure>

usbank®

</figure>


November 2020 Statement 10/03/2020 - 11/02/2020
DAVID L BARG

<!-- PageNumber="Page 3 of 3" -->

Cardmember Service

C

1-800-285-8585

Transactions

Interest Charged


<table>
<tr>
<th>Post Date</th>
<th>Transaction Description</th>
<th>Amount</th>
</tr>
<tr>
<td>11/02</td>
<td>INTEREST CHARGE ON PURCHASES</td>
<td>$96.67</td>
</tr>
<tr>
<td>11/02</td>
<td>INTEREST CHARGE ON CASH ADVANCES</td>
<td>$46.26</td>
</tr>
<tr>
<td></td>
<td>TOTAL INTEREST THIS PERIOD</td>
<td>$142.93</td>
</tr>
</table>


<table>
<tr>
<td colspan="2">2020 Totals Year-to-Date</td>
</tr>
<tr>
<td>Total Fees Charged in 2020</td>
<td>$0.00</td>
</tr>
<tr>
<td>Total Interest Charged in 2020</td>
<td>$1,510.22</td>
</tr>
</table>


Interest Charge Calculation

Your Annual Percentage Rate (APR) is the annual interest rate on your account.

** APR for current and future transactions.


<table>
<tr>
<th>Balance Type</th>
<th>Balance By Type</th>
<th>Balance Subject to Interest Rate</th>
<th>Variable</th>
<th>Interest Charge</th>
<th>Annual Percentage Rate</th>
<th>Expires with Statement</th>
</tr>
<tr>
<td>** BALANCE TRANSFER</td>
<td>$0.00</td>
<td>$0.00</td>
<td>YES</td>
<td>$0.00</td>
<td>21.99%</td>
<td></td>
</tr>
<tr>
<td>** PURCHASES</td>
<td>$5,300.38</td>
<td>$5,176.12</td>
<td>YES</td>
<td>$96.67</td>
<td>21.99%</td>
<td></td>
</tr>
<tr>
<td>** ADVANCES</td>
<td>$2,316.96</td>
<td>$2,270.70</td>
<td>YES</td>
<td>$46.26</td>
<td>23.99%</td>
<td></td>
</tr>
</table>


Contact Us

C

Phone

?

Questions

POST
☒
Mail payment coupon
with a check

Online

Voice:

1-800-285-8585

TDD:

1-888-352-6455

Fax:
1-866-568-7729

Cardmember Service

P.O. Box 6352

Fargo, ND 58125-6352

U.S. Bank

P.O. Box 790408

St. Louis, MO 63179-0408

usbank.com

End of Statement


<figure>

PayPal

</figure>


DAVID L BARG

Link your credit card
to PayPal today !!!
Experience faster checkouts, added security and convenience.
It's all there for you when you link your card to PayPal.

Link your card in the U.S. Bank Mobile App or log in to usbank.com today.
Recent updates to your account may impact your eligibility to enroll in PayPal.

<!-- PageFooter="/12915" -->
<!-- PageBreak -->

