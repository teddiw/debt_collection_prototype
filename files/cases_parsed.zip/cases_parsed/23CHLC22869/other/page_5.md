11\. The documents attached hereto are true and correct copies of the originals, being a reproduction of the records
on file on behalf of Plaintiff based upon my review, except to the extent that confidential and privileged
information and/or personal identifying information is omitted or redacted as required by local rules, and
applicable state and federal laws.

12\. If called upon to testify as a witness thereon, I could and would competently testify as to all the facts stated
herein.

I declare under penalty of perjury under the laws of the State of California that the foregoing is true and correct.

Dated: 11/13/2023

PO

Pamela Jordan

RESURGENT CAPITAL SERVICES,
as authorized representative of
LVNV Funding LLC

<!-- PageNumber="Page 4" -->
<!-- PageFooter="DECLARATION IN SUPPORT OF APPLICATION FOR ENTRY OF DEFAULT JUDGMENT PURSUANT TO CIVIL CODE § 1788.60" -->
<!-- PageFooter="/12915" -->

1.001

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28

<!-- PageBreak -->

