Exhibit A

Receivables File
06.27.22 795_usb_sale_20220621


<table>
<tr>
<th>Transfer Group</th>
<th>Portfolio</th>
<th>Transfer Batch</th>
</tr>
<tr>
<td>832793</td>
<td>40231</td>
<td>N/A</td>
</tr>
</table>


<!-- PageFooter="/12915" -->
<!-- PageBreak -->

