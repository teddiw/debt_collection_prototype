
<figure>

usbank.

</figure>


November 2020 Statement
DAVID L BARG

10/03/2020 - 11/02/2020

<!-- PageNumber="Page 2 of 3" -->

Cardmember Service

C
1-800-285-8585

Important Messages

Paying Interest: You have a 24 to 30 day interest-free period for Purchases provided you have paid your
previous balance in full by the Payment Due Date shown on your monthly Account statement. In order to
avoid additional INTEREST CHARGES on Purchases, you must pay your new balance in full by the
Payment Due Date shown on the front of your monthly Account statement.

There is no interest-free period for transactions that post to the Account as Advances or Balance Transfers
except as provided in any Offer Materials. Those transactions are subject to interest from the date they post
to the Account until the date they are paid in full.

If you believe we have inaccurately reported information to any Consumer Reporting Agency, you may
submit a dispute by writing to us. In order for us to assist you with your dispute, you must provide your
name, address, phone number, account number, the specific information you are disputing, the explanation
of why it is incorrect, and any supporting documentation (e.g., affidavit of identity theft), if applicable, to:

U.S. Bank National Association
Consumer Recovery Department
Attn: CBR Disputes
P.O. Box 108
St Louis, MO 63166-0108

Speed through check out with the added security and convenience of PayPal. Use the U.S. Bank Mobile
App or log in to Online Banking to link your card to PayPal today.

Skip the mailbox. Switch to e-statements and securely access your statements online. Get started at
usbank.com/login.

Transactions

Payments and Other Credits


<table>
<tr>
<th>Post Date</th>
<th>Trans Date</th>
<th>Ref #</th>
<th>Transaction Description</th>
<th>Amount</th>
</tr>
<tr>
<td>10/23</td>
<td>10/23</td>
<td>0037</td>
<td>BRANCH PAYMENT THANK YOU</td>
<td>$213.00CR</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>TOTAL THIS PERIOD</td>
<td>$213.00CR</td>
</tr>
</table>


Purchases and Other Debits


<table>
<tr>
<th>Post Date</th>
<th>Trans Date</th>
<th>Ref #</th>
<th>Transaction Description</th>
<th>Amount</th>
</tr>
<tr>
<td>10/05</td>
<td>10/03</td>
<td>1192</td>
<td>PARIS CLEANERS ENCINO CA</td>
<td>$22.75</td>
</tr>
<tr>
<td>10/05</td>
<td>10/03</td>
<td>3450</td>
<td>LIGHT BULBS UNLIMITED SHERMAN OAKS CA</td>
<td>$36.03</td>
</tr>
<tr>
<td>10/05</td>
<td>10/01</td>
<td>9778</td>
<td>OFFICE DEPOT #3320 TARZANA CA</td>
<td>$240.66</td>
</tr>
<tr>
<td>10/09</td>
<td>10/08</td>
<td>8302</td>
<td>WALGREENS #11735 ENCINO CA</td>
<td>$42.58</td>
</tr>
<tr>
<td>10/13</td>
<td>10/09</td>
<td>7129</td>
<td>SEES CANDY 19104 ENCINO CA</td>
<td>$21.93</td>
</tr>
<tr>
<td>10/13</td>
<td>10/10</td>
<td>1428</td>
<td>HAPPY DAYS ACE HARDWAR ENCINO CA</td>
<td>$17.05</td>
</tr>
<tr>
<td>10/13</td>
<td>10/10</td>
<td>6806</td>
<td>BEVERAGES &amp; MORE #129 ENCINO CA</td>
<td>$14.88</td>
</tr>
<tr>
<td>10/13</td>
<td>10/10</td>
<td>1500</td>
<td>GELSON'S MARKETS #2 ENCINO CA</td>
<td>$40.28</td>
</tr>
<tr>
<td>10/19</td>
<td>10/16</td>
<td>1834</td>
<td>GELSON'S MARKETS #2 ENCINO CA</td>
<td>$48.21</td>
</tr>
<tr>
<td>10/19</td>
<td>10/16</td>
<td>0927</td>
<td>MAYO CLINIC PRESS ROCHESTER MN</td>
<td>$34.04</td>
</tr>
<tr>
<td>10/19</td>
<td>10/16</td>
<td>3613</td>
<td>PARIS CLEANERS ENCINO CA</td>
<td>$19.75</td>
</tr>
<tr>
<td>10/20</td>
<td>10/18</td>
<td>8614</td>
<td>WESTLAKE ACE VAN NUYS# VAN NUYS CA</td>
<td>$8.75</td>
</tr>
<tr>
<td>11/02</td>
<td>10/30</td>
<td>8056</td>
<td>SUPER WOK TARZANA CA</td>
<td>$36.79</td>
</tr>
<tr>
<td>11/02</td>
<td>10/31</td>
<td>7448</td>
<td>PARIS CLEANERS ENCINO CA</td>
<td>$41.25</td>
</tr>
<tr>
<td>11/02</td>
<td>11/01</td>
<td>6587</td>
<td>RALPHS #0006 ENCINO CA</td>
<td>$22.74</td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td>TOTAL THIS PERIOD</td>
<td>$647.69</td>
</tr>
</table>


<!-- PageFooter="Continued on Next Page" -->
<!-- PageFooter="/12915" -->
<!-- PageBreak -->

