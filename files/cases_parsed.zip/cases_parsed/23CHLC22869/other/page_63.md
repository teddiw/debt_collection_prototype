EXHIBIT C

<!-- PageNumber="/12915" -->
<!-- PageBreak -->

