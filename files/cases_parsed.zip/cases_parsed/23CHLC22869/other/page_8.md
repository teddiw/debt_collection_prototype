
## Declaration of Account Transfer

Resurgent Acquisitions LLC ("RALLC"), without recourse, to the extent permitted by
applicable law, transferred, sold, assigned, conveyed, granted and delivered to LVNV Funding
LLC ("LVNV") all of its right, title and interest in and to the receivables and other assets (the
"Assets") identified on Exhibit A, in the Receivable File dated June 21, 2022 delivered by U.S.
Bank, N.A. on June 27, 2022 for purchase by RALLC on June 27, 2022. The transfer of the
Assets included electronically stored business records.

Resurgent Acquisitions LLC
a Delaware Limited Liability Company


<figure>

By:
Jan Walker

Name: Jackson Walker
Title: Authorized Representative

</figure>


LVNV Funding LLC
a Delaware Limited Liability Company

Bys

Name: Daniel Picciano

Title: Authorized Representative

<!-- PageNumber="/12915" -->
<!-- PageBreak -->

