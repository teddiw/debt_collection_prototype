
<figure>
</figure>


RESURGENCE
LEGAL GROUP, PC
10805 Holder Street, Suite 167
Cypress, CA 90630
T: 877/440-0860
F: 714/226-0024
8:30am-5:00pm (local time)
www.resurgencelegal.com

July 24, 2023
California Debt Collection License #10749-99.

DAVID BARG
3454 CARIBETH DR
ENCINO CA 91436

RE:

Reference Number: TP126445

Current Creditor: LVNV FUNDING LLC

Original Creditor: US BANK NA

Account Number: ************ 2537

Balance Due: $9,339.79

Dear Sir/Madam:


# NOTICE OF INTENTION TO FILE LITIGATION AND INCUR COURT COSTS AND LEGAL FEES

Please be advised that this law firm intends to enforce our client's claim through applicable legal proceedings to obtain
payment of the above-referenced matter.

Pursuant to the Code of Civil Procedure Section 1033(b)(2), this letter advises you that if this matter remains unresolved,
our intent is to pursue litigation against you in the Superior Court of California. Please note that the litigation could result
in a judgment against you which may include our client's court costs and necessary disbursements, all of which you could
become responsible for, as allowed under California applicable law.

THIS COMMUNICATION IS A NOTICE BY A DEBT COLLECTOR MADE PURSUANT TO
CALIFORNIA LAW CONCERNING POTENTIAL LITIGATION.

Very truly yours,

RESURGENCE LEGAL GROUP, PC

This communication is from a debt collector and is an attempt to collect a debt. Any information obtained will be used
for that purpose.

<!-- PageFooter="California Illinois + Minnesota + Wisconsin" -->
