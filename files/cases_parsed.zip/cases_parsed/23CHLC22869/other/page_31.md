<!-- PageNumber="/12915" -->

OriginalChargeoffAdditionalBalanceCategoryAmount9
[Redacted]
[Redacted]
[Redacted]
[Redacted]
[Redacted]
[Redacted]
[Redacted]
[Redacted]
[Redacted]
[Redacted]
0
[Redacted]
[Redacted]
[Redacted]
[Redacted]

[Redacted]
[Redacted]
[Redacted]
[Redacted]
[Redacted]
[Redacted]


<table>
<tr>
<th></th>
<th>CurrentChargeoffAdditionalBalanceCategoryAmount9</th>
</tr>
<tr>
<td colspan="2">[Redacted]</td>
</tr>
<tr>
<td colspan="2">[Redacted]</td>
</tr>
<tr>
<td></td>
<td>[Redacted]</td>
</tr>
<tr>
<td></td>
<td>[Redacted]</td>
</tr>
<tr>
<td></td>
<td>[Redacted]</td>
</tr>
<tr>
<td></td>
<td>[Redacted]</td>
</tr>
<tr>
<td colspan="2">[Redacted]</td>
</tr>
<tr>
<td></td>
<td>[Redacted]</td>
</tr>
<tr>
<td></td>
<td>[Redacted]</td>
</tr>
<tr>
<td colspan="2">[Redacted]</td>
</tr>
<tr>
<td colspan="2">0 [Redacted]</td>
</tr>
<tr>
<td colspan="2">[Redacted]</td>
</tr>
<tr>
<td colspan="2">[Redacted]</td>
</tr>
<tr>
<td colspan="2">[Redacted]</td>
</tr>
<tr>
<td colspan="2">[Redacted]</td>
</tr>
<tr>
<td colspan="2">[Redacted]</td>
</tr>
<tr>
<td colspan="2">[Redacted]</td>
</tr>
<tr>
<td></td>
<td>[Redacted]</td>
</tr>
<tr>
<td></td>
<td>[Redacted]</td>
</tr>
<tr>
<td></td>
<td>[Redacted]</td>
</tr>
</table>


<!-- PageBreak -->

