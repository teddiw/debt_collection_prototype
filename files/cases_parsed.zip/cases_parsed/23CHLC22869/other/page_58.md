EXHIBIT B

<!-- PageNumber="/12915" -->
<!-- PageBreak -->

