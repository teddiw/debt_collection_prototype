<!-- PageNumber="/12915" -->

OriginalChargeoffAdditionalBalanceCategoryAmount7

[Redacted]
[Redacted]
[Redacted]
[Redacted]


### CurrentChargeoffAdditionalBalanceCategoryAmount7

[Redacted]
[Redacted]
[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]
[Redacted]
[Redacted]
[Redacted]
[Redacted]
0
[Redacted]
[Redacted]
[Redacted]
[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

0

[Redacted]

[Redacted]
[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]
[Redacted]
[Redacted]
[Redacted]
[Redacted]

[Redacted]
[Redacted]
[Redacted]

[Redacted]

<!-- PageBreak -->

