<!-- PageNumber="/12915" -->

OriginalChargeoffAdditionalBalanceCategoryAmount17

[Redacted]

[Redacted]
[Redacted]
[Redacted]

[Redacted]
[Redacted]

[Redacted]

[Redacted]

[Redacted]
[Redacted]

[Redacted]

0

[Redacted]
0
[Redacted]
[Redacted]
[Redacted]
[Redacted]

[Redacted]
[Redacted]
[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]
[Redacted]
[Redacted]
[Redacted]
[Redacted]

[Redacted]
[Redacted]
[Redacted]
[Redacted]

[Redacted]


### CurrentChargeoffAdditionalBalanceCategoryAmount17

[Redacted]
[Redacted]
[Redacted]

[Redacted]

[Redacted]
[Redacted]
[Redacted]
[Redacted]

<!-- PageBreak -->

