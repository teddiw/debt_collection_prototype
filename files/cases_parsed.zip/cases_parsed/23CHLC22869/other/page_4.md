1
2
3
4
:

g. Defendants name and last known address as it appeared in the charge off creditor's records:
DAVID BARG
3454 CARIBETH DR, ENCINO CA 91436-4102

h. The complete chain of title including U.S. Bank, N.A. and all post charge off purchasers of the debt are as
follows:


<table>
<tr>
<th>Date Of Transfer</th>
<th>Owner/Creditor Name</th>
<th>Owner/CreditorAddress</th>
</tr>
<tr>
<td>6/27/2022</td>
<td>U.S. Bank, N.A.</td>
<td>60 Livingstone Ave EP-MN-WS3D St. Paul MN 55107</td>
</tr>
<tr>
<td>6/27/2022</td>
<td>Resurgent Acquisitions LLC C/O Resurgent Capital Services LP</td>
<td>P.O. Box 10466 Greenville SC 29603</td>
</tr>
<tr>
<td></td>
<td>LVNV Funding LLC C/O Resurgent Capital Services LP</td>
<td>P.O. Box 10466 Greenville SC 29603</td>
</tr>
</table>


9\. LVNV Funding LLC's records state that LVNV Funding LLC or its agents made demand for payment of the
balance herein prior to making this affidavit and Defendant(s) failed to make full payment of the amount owed
on the Account.

10\. Attached hereto as Exhibits A, B, and C are the account records I reviewed in executing the affidavit that relate
to the Account and/or payment(s) received.

Exhibit A: Chain of Title and Seller Data Document - Establishing the facts required under Civil Code section
1788.58(a)(3) and (8)

Exhibit B: Last Monthly Billing Statement Recording a Purchase, Last Payment, or Balance Transfer -
Establishing the facts required under Civil Code section 1788.52 (b) and/or 1788.58(a)(5)

Exhibit C: Billing Statement(s) - Establishing the facts required under Civil Code section 1788.58 (a)(4) and (6)

<!-- PageFooter="/12915" -->
<!-- PageNumber="Page 3" -->
<!-- PageFooter="DECLARATION IN SUPPORT OF APPLICATION FOR ENTRY OF DEFAULT JUDGMENT PURSUANT TO CIVIL CODE § 1788.60" -->

1.001

5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28

<!-- PageBreak -->

