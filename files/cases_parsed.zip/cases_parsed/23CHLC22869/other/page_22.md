<!-- PageNumber="/12915" -->

OriginalChargeoffAdditionalBalanceCategoryAmount3
[Redacted]
[Redacted]
[Redacted]
[Redacted]


### CurrentChargeoffAdditionalBalanceCategoryAmount3

[Redacted]
[Redacted]
[Redacted]

[Redacted]

[Redacted]

[Redacted]
[Redacted]

[Redacted]
[Redacted]
[Redacted]
[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]
0

[Redacted]
0
[Redacted]
[Redacted]
[Redacted]
[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]

[Redacted]
[Redacted]
[Redacted]
[Redacted]
[Redacted]
[Redacted]

[Redacted]

[Redacted]
[Redacted]

[Redacted]

<!-- PageBreak -->

