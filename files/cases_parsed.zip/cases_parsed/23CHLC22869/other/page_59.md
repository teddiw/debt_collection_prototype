usbank.

November 2020 Statement
Open Date: 10/03/2020 Closing Date: 11/02/2020

U.S. Bank Platinum Visa® Card
DAVID L BARG


<table>
<tr>
<td>New Balance</td>
<td>$7,617.34</td>
</tr>
<tr>
<td>Minimum Payment Due</td>
<td>$218.00</td>
</tr>
<tr>
<td>Payment Due Date</td>
<td>11/28/2020</td>
</tr>
<tr>
<td colspan="2">Late Payment Warning; If we do not receive your minimum payment by the date listed above, you may have to pay up to a $40.00 Late Fee</td>
</tr>
</table>


Minimum Payment Warning: If you make only the minimum
payment each period, you will pay more in interest and it will
take you longer to pay off your balance. For example:


<table>
<tr>
<th>If you make no additional charges using this card and each month you pay ...</th>
<th>You will pay off the balance shown on this statement in about ...</th>
<th>And you will end up paying an estimated total of ...</th>
</tr>
<tr>
<td>Only the minimum payment</td>
<td>13 years</td>
<td>$18,524</td>
</tr>
<tr>
<td>$293</td>
<td>3 years</td>
<td>$10,557 (Savings=$7,967)</td>
</tr>
</table>


If you would like information about credit counseling services,
call 866-951-1391.


<table>
<tr>
<th></th>
<th colspan="2"></th>
<th></th>
<th>Page 1 of 3</th>
</tr>
<tr>
<th colspan="3">Account:</th>
<th></th>
<th>2537</th>
</tr>
<tr>
<td colspan="4">Cardmember Service</td>
<td>1-800-285-8585</td>
</tr>
<tr>
<th>BNK 25 US2</th>
<th colspan="2">8</th>
<th></th>
<th>1</th>
</tr>
<tr>
<td colspan="3">Activity Summary .</td>
<td></td>
<td></td>
</tr>
<tr>
<td>Previous Balance</td>
<td colspan="2"></td>
<td>+</td>
<td>$7,039.72</td>
</tr>
<tr>
<td>Payments</td>
<td colspan="2"></td>
<td>-</td>
<td>$213.00CR</td>
</tr>
<tr>
<td>Other Credits</td>
<td colspan="2"></td>
<td></td>
<td>$0.00</td>
</tr>
<tr>
<td>Purchases</td>
<td colspan="2"></td>
<td>+</td>
<td>$647.69</td>
</tr>
<tr>
<td colspan="3">Balance Transfers</td>
<td></td>
<td>$0.00</td>
</tr>
<tr>
<td>Advances</td>
<td colspan="2"></td>
<td></td>
<td>$0.00</td>
</tr>
<tr>
<td>Other Debits</td>
<td colspan="2"></td>
<td></td>
<td>$0.00</td>
</tr>
<tr>
<td colspan="2">Fees Charged</td>
<td></td>
<td></td>
<td>$0.00</td>
</tr>
<tr>
<td>Interest Charged</td>
<td colspan="2"></td>
<td>+</td>
<td>$142.93</td>
</tr>
<tr>
<td>New Balance</td>
<td></td>
<td></td>
<td>=</td>
<td>$7,617.34</td>
</tr>
<tr>
<td>Past Due</td>
<td colspan="2"></td>
<td></td>
<td>$0.00</td>
</tr>
<tr>
<td colspan="2">Minimum Payment Due</td>
<td></td>
<td></td>
<td>$218.00</td>
</tr>
<tr>
<td>Credit Line</td>
<td></td>
<td></td>
<td></td>
<td>$8,500.00</td>
</tr>
<tr>
<td colspan="3">Available Credit</td>
<td></td>
<td>$882.66</td>
</tr>
<tr>
<td colspan="4">Days in Billing Period</td>
<td>31</td>
</tr>
</table>


<figure>

Payment
Options:

POST
Mail payment coupon

Pay online at
usbank.com

Pay by phone
1-800-285-8585

Pay at your local
U.S. Bank branch

with a check

Please detach and send coupon with check payable to: U.S. Bank

usbank.

2537

24-Hour Cardmember Service: 1-800-285-8585

. to pay by phone
. to change your address

Amount Enclosed
$

000035431 01 SP
000638623163892 P Y

DAVID L BARG
3454 CARIBETH DR
ENCINO CA 91436-4102

U.S. Bank
P.O. Box 790408
St. Louis, MO 63179-0408

</figure>


<table>
<tr>
<td>Account Number</td>
<td>2537</td>
</tr>
<tr>
<td>Payment Due Date</td>
<td>11/28/2020</td>
</tr>
<tr>
<td>New Balance</td>
<td>$7,617.34</td>
</tr>
<tr>
<td>Minimum Payment Due</td>
<td>$218.00</td>
</tr>
</table>


<!-- PageFooter="/12915" -->
<!-- PageBreak -->

