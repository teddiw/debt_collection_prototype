/12915


<table>
<tr>
<th>CurrentChargeoffAdditionalBalanceCategoryAmount8</th>
<th>PaidChargeoffAdditionalBalanceCategoryAmount8</th>
<th colspan="2">AdditionalBalanceCategoryDescription9</th>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td colspan="2">[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td colspan="2">[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td></td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td></td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td colspan="2">[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td></td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td></td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td></td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td></td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td colspan="2">[Redacted]</td>
</tr>
<tr>
<td>0</td>
<td>0</td>
<td colspan="2">0</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td colspan="2">[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td colspan="2">[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td></td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td></td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td></td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td></td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td></td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td colspan="2">[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td colspan="2">[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td colspan="2">[Redacted]</td>
</tr>
</table>


<!-- PageBreak -->

