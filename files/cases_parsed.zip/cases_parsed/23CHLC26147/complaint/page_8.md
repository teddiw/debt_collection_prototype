<!-- PageNumber="Page 2 of 2" -->

Customer Service 1-855-378-6467
TTY:711

www.citicards.com

JOSHUA ANDERSON

CARDHOLDER SUMMARY


<table>
<tr>
<td>JOSHUA ANDERSON</td>
<td>Card ending in 0080</td>
</tr>
<tr>
<td>New Charges</td>
<td>$0.00</td>
</tr>
</table>


## ACCOUNT SUMMARY


<table>
<tr>
<th>Sale Date</th>
<th>Post Date</th>
<th>Description</th>
<th>Amount</th>
</tr>
<tr>
<td colspan="4">Payments, Credits and Adjustments</td>
</tr>
<tr>
<td></td>
<td>04/21</td>
<td>ONLINE PAYMENT, THANK YOU</td>
<td>-$120.01</td>
</tr>
</table>


JOSHUA ANDERSON

No Activity

Fees Charged


<table>
<tr>
<td>04/22 LATE FEE - MAR PAYMENT PAST DUE</td>
<td>$40.00</td>
</tr>
<tr>
<td>TOTAL FEES FOR THIS PERIOD</td>
<td>$40.00</td>
</tr>
</table>


Interest Charged


<table>
<tr>
<td>04/22 INTEREST CHARGED TO STANDARD PURCH</td>
<td>$24.04</td>
</tr>
<tr>
<td>TOTAL INTEREST FOR THIS PERIOD</td>
<td>$24.04</td>
</tr>
</table>


<table>
<tr>
<td>2022 totals year-to-date</td>
<td></td>
</tr>
<tr>
<td>Total fees charged in 2022</td>
<td>$120.00</td>
</tr>
<tr>
<td>Total interest charged in 2022</td>
<td>$95.40</td>
</tr>
</table>


Interest charge calculation
Days in billing cycle: 31

Your Annual Percentage Rate (APR) is the annual interest rate on your account.


<table>
<tr>
<th>Balance type</th>
<th>Annual percentage rate (APR)</th>
<th>Balance subject to interest rate</th>
<th>Interest charge</th>
</tr>
<tr>
<td>PURCHASES</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Standard Purch</td>
<td>15.49% (V)</td>
<td>$1,827.21 (D)</td>
<td>$24.04</td>
</tr>
<tr>
<td>ADVANCES</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Standard Adv</td>
<td>25.49% (V)</td>
<td>$0.00 (D)</td>
<td>$0.00</td>
</tr>
</table>


Your Annual Percentage Rate (APR) is the annual interest rate on your account. APRs followed
by (V) may vary. Balances followed by (D) are determined by the daily balance method
(including current transactions).


### Account messages

Please be sure to pay on time. If you submit your payment by mail, we suggest
you mail it no later than 05/13/2022 to allow enough time for regular mail to
reach us.

@2022 Citibank, N.A.
Citi, and Citi with Arc Design are registered service marks of Citigroup Inc.
Visa® is a registered trademark of Visa International Service Association and
used under license.

<!-- PageBreak -->

