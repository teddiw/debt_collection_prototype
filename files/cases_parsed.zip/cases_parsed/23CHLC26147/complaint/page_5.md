WHEREFORE, Plaintiff prays for judgment against the Defendant as follows:

1\. For the damages and money in the sum of $2,209.89,

2\. For reasonable attorneys fees pursuant to statute;

3\. For costs of suit incurred; and

4\. For such other and further relief as the Court deems just and proper.

5\. Plaintiff remits all damages in excess of the jurisdictional amount of this Court.

Dated: 09/27/2023

By:

MANDARICH LAW GROUP, LLP

Jager

☒
Teona Pipia, Esq.
X

Attorneys for Plaintiff

<!-- PageFooter="COMPLAINT-5 of 5" -->

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28

<!-- PageBreak -->

