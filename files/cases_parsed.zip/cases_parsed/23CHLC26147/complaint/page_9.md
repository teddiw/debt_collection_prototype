EXHIBIT B

<!-- PageBreak -->

