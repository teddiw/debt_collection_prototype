and/or take cash advances and/or make balance transfers, Defendant reaffirmed their agreement to
repay CITIBANK, N.A. and its successors in interest for the amount of the purchase and/or cash
advances and/or balance transfers.

13.Monthly statements were sent to Defendant which itemized all payments made and
charges due on the Account.

14\. The date of last payment on the subject account was on April 21, 2022.

15\. Within the last four years, the Defendant failed to make payments as agreed on the
Account. Defendant has failed, refused and neglected to pay amounts due on the Account.

16\. The debt balance at charge-off was $2,209.89, and upon information and belief there is
$0.00 in post charge off fees and $0.00 in post charge off interest.

17.Subsequent to charge-off, and after applying any and all applicable payments and
credits, the Defendant owes Plaintiff $2,209.89.

18.Although demand has been made upon said Defendant to pay said amount, no part has
been paid, and it is now due and owing.

19.Upon information and belief, CITIBANK, N.A. and successors in interest including
Plaintiff have duly performed all promises, conditions and agreements herein.

20.Plaintiff has complied with California Civil Code Section 1788.52.

21.Plaintiff has attached hereto as Exhibit A and incorporated herein by reference a copy
of Billing Statement and/or Account Records provided to the Defendant while the account was
active, demonstrating that the debt was incurred by the Defendant as described in California Civil
Code section 1788.52(b).

22.Plaintiff has attached hereto as Exhibit B and incorporated herein by reference a copy
of the Final Billing Statement and/or Transaction History.

23.Upon opening the Account with CITIBANK, N.A., the Defendant(s) agree to reimburse
CITIBANK, N.A., and hence Plaintiff as successor in interest for the costs related to the collection
of amounts owing on the Account. Plaintiff has been required to retain Mandarich Law Group,

<!-- PageFooter="COMPLAINT-3 of 5" -->

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28

<!-- PageBreak -->

