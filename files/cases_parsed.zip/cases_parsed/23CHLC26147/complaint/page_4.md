LLP to pursue collection of the amount due hereunder.


# FIRST CAUSE OF ACTION (Account Stated)

24.Plaintiff refers to and incorporates paragraphs 1 through 23.

25\. Within the past 4 years, an account was stated in writing in which it was agreed that
Defendant were indebted in the amount previously referenced herein. Although demand has been
made upon Defendant, said amount of $2,209.89 has not been paid, and it is now due, owing and
unpaid from Defendant to Plaintiff, as successor in interest.


# SECOND CAUSE OF ACTION (Open Book Account)

26.Plaintiff refers to and incorporates paragraphs 1 through 25.

27\. Within the past 4 years, Defendant and each of them became indebted in the amount of
the previously mentioned herein for a balance due on a book account for goods sold and delivered
and/or services rendered by CITIBANK, N.A .. Although demand has been made upon Defendant,
said amount of $2,209.89 has not been paid, and it is now due, owing and unpaid including
attorney's fees from Defendant to Plaintiff as successor in interest.

<!-- PageFooter="COMPLAINT-4 of 5" -->

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28

<!-- PageBreak -->

