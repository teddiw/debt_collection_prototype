Costco Anywhere Visa® Card by Citi


<figure>

cítì

COSTCO
WHOLESALE

</figure>


JOSHUA ANDERSON
Member Since 2016 Account number ending in: 0080
Billing Period: 03/23/22-04/22/22

APRIL STATEMENT


<table>
<tr>
<td>Minimum payment due:</td>
<td>$82.04</td>
</tr>
<tr>
<td>New balance as of 04/22/22:</td>
<td>$1,767.33</td>
</tr>
<tr>
<td>Payment due date:</td>
<td>05/20/22</td>
</tr>
</table>


See the last page of this statement for important information about how to
avoid paying interest on purchases.

Late Payment Warning: If we do not receive your minimum payment by the date
listed above, you may have to pay a late fee of up to $40 and your APRs may be
increased up to the Penalty APR of 29.99%.

Minimum payment warning: If you make only the minimum payment each
period, you will pay more in interest, and it will take you longer to pay off
your balance. For example:


<table>
<tr>
<th>If you make no additional charges using this card and each month you pay ...</th>
<th>You will pay off the balance shown on the statement in about ...</th>
<th>And you will end up paying an estimated total of ...</th>
</tr>
<tr>
<td>Only the minimum payment</td>
<td>6 years</td>
<td>$2,738</td>
</tr>
</table>


For information about credit counseling services, call 1-877-337-8187.

www.citicards.com
Customer Service 1-855-378-6467

TTY:711
PO Box 790046 ST. LOUIS, MO 63179-0046

Account Summary


<table>
<tr>
<td>Previous balance</td>
<td>$1,823.30</td>
</tr>
<tr>
<td>Payments</td>
<td>-$120.01</td>
</tr>
<tr>
<td>Credits</td>
<td>-$0.00</td>
</tr>
<tr>
<td>Purchases</td>
<td>+$0.00</td>
</tr>
<tr>
<td>Cash advances</td>
<td>+$0.00</td>
</tr>
<tr>
<td>Fees</td>
<td>+$40.00</td>
</tr>
<tr>
<td>Interest</td>
<td>+$24.04</td>
</tr>
<tr>
<td>New balance</td>
<td>$1,767.33</td>
</tr>
<tr>
<td>Credit Limit</td>
<td></td>
</tr>
<tr>
<td>Credit Limit</td>
<td>$4,000</td>
</tr>
</table>


Includes $1,200.00 cash advance limit

For Payments, send check to: Citi Cards, PO BOX 78019, Phoenix, AZ, 85062-8019

Pay your bill from virtually anywhere
with the Citi Mobile® App and Citi® Online

citi

To download:
Text 'App15' to MyCiti (692484)
or go to your device's app store.
Or visit www.citicards.com


<table>
<tr>
<td>Minimum payment due</td>
<td>$82.04</td>
</tr>
<tr>
<td>New balance</td>
<td>$1,767.33</td>
</tr>
<tr>
<td>Payment due date</td>
<td>05/20/22</td>
</tr>
</table>


Amount enclosed:

Account number ending in 0080
Please make check payable to Citi Cards.

000000 NC 22 A 0

JOSHUA ANDERSON
16653 OLDHAM PL
ENCINO CA 91436-3707

Citi Cards
PO BOX 78019
Phoenix, AZ 85062-8019

<!-- PageBreak -->

