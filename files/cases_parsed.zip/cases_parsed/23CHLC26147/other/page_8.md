Contract ID: CV8MUMAA122922
Addendum ID: CV8MUMAA122922C1
Document ID: 011723CVICCIFMA1


## Exhibit 1

The individual Accounts transferred are described in the final electronic file and delivered by the
Bank to Buyer, the same deemed attached hereto by this reference.


<table>
<tr>
<th>Lot</th>
<th>Sale ID</th>
<th># of Accounts</th>
<th>Sale Balance</th>
<th>Cut-Off Date</th>
</tr>
<tr>
<td>Costco Fresh</td>
<td>011723CV1CC1FM</td>
<td></td>
<td></td>
<td>1/17/2023</td>
</tr>
</table>


<!-- PageNumber="1" -->
<!-- PageFooter="Cavalry 122922" -->
<!-- PageBreak -->

