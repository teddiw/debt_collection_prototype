12\.
If called upon to testify as a witness thereon, I could and would competently
testify as to all the facts stated herein.

I declare under penalty of perjury under the laws of the State of California that the foregoing is
true and correct.

Executed this 12 day of September 2024, at Fort Lauderdale, Florida.

Signature:
8

By:
Romona Gibson

Title: Legal Administrator

<!-- PageFooter="DECLARATION IN SUPPORT OF APPLICATION FOR ENTRY OF DEFAULT JUDGMENT (CIVIL CODE $ 1788.60(a)" -->
<!-- PageNumber="5" -->

1
2
3
4
5.
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28

<!-- PageBreak -->

