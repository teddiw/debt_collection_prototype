<!-- PageNumber="Page 2 of 2" -->

Customer Service 1-855-378-6467
TTY:711

<!-- PageHeader="www.citicards.com" -->

JOSHUA ANDERSON

CARDHOLDER SUMMARY


<table>
<tr>
<td>JOSHUA ANDERSON</td>
<td>Card ending in 0080</td>
</tr>
<tr>
<td>New Charges</td>
<td>$0.00</td>
</tr>
</table>


## ACCOUNT SUMMARY


<table>
<tr>
<th>Sale Date</th>
<th>Post Date Description</th>
<th>Amount</th>
</tr>
<tr>
<td colspan="2">JOSHUA ANDERSON</td>
<td></td>
</tr>
<tr>
<td colspan="2">No Activity</td>
<td></td>
</tr>
<tr>
<td colspan="2">Fees Charged</td>
<td></td>
</tr>
<tr>
<td>TOTAL</td>
<td>FEES FOR THIS PERIOD</td>
<td>$0.00</td>
</tr>
<tr>
<td colspan="2">Interest Charged</td>
<td></td>
</tr>
<tr>
<td>11/22</td>
<td>INTEREST CHARGED TO STANDARD PURCH</td>
<td>$33.09</td>
</tr>
<tr>
<td colspan="2">TOTAL INTEREST FOR THIS PERIOD</td>
<td>$33.09</td>
</tr>
</table>


<table>
<tr>
<td>2022 totals year-to-date</td>
<td></td>
</tr>
<tr>
<td>Total fees charged in 2022</td>
<td>$360.00</td>
</tr>
<tr>
<td>Total interest charged in 2022</td>
<td>$297.96</td>
</tr>
</table>


Interest charge calculation
Days in billing cycle: 29

Your Annual Percentage Rate (APR) is the annual interest rate on your account.


<table>
<tr>
<th>Balance type</th>
<th>Annual percentage rate (APR)</th>
<th>Balance subject to interest rate</th>
<th>Interest charge</th>
</tr>
<tr>
<td>PURCHASES</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Standard Purch</td>
<td>18.99% (V)</td>
<td>$2,192.73 (D)</td>
<td>$33.09</td>
</tr>
<tr>
<td>ADVANCES</td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Standard Adv</td>
<td>28.99% (V)</td>
<td>$0.00 (D)</td>
<td>$0.00</td>
</tr>
</table>


Your Annual Percentage Rate (APR) is the annual interest rate on your account. APRs followed
by (V) may vary. Balances followed by (D) are determined by the daily balance method
(including current transactions).


### Account messages

Please note that if we received your pay by phone or online payment between
5 p.m. ET and midnight ET on the last day of your billing period, your payment
was credited as of the date of receipt, but will not be reflected until your next
statement.

@2022 Citibank, N.A.
Citi, and Citi with Arc Design are registered service marks of Citigroup Inc.
Visa® is a registered trademark of Visa International Service Association and
used under license.
