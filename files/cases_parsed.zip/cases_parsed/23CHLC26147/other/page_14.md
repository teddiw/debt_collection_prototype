
<figure>

citi

COSTEQ
WHOLESALE

</figure>


Costco Anywhere Visa® Card by Citi

JOSHUA ANDERSON
Member Since 2016 Account number ending in: 0080
Billing Period: 10/25/22-11/22/22

NOVEMBER STATEMENT


<table>
<tr>
<td>Minimum payment due:</td>
<td>$2,209.89</td>
</tr>
<tr>
<td>New balance as of 11/22/22:</td>
<td>$2,209.89</td>
</tr>
<tr>
<td>Payment due date:</td>
<td>11/22/22</td>
</tr>
</table>


See the last page of this statement for important information about how to
avoid paying interest on purchases.

Late Payment Warning: If we do not receive your minimum payment by the date
listed above, you may have to pay a late fee of up to $40 and your APRs may be
increased up to the Penalty APR of 29.99%.

Minimum payment warning: If you make only the minimum payment each
period, you will pay more in interest, and it will take you longer to pay off
your balance. For example:


<table>
<tr>
<td>If you make no additional charges using this card and each month you pay ...</td>
<td>You will pay off the balance shown on the statement in about ...</td>
<td>And you will end up paying an estimated total of ...</td>
</tr>
<tr>
<td>Only the minimum payment</td>
<td>1 months</td>
<td>$2,210</td>
</tr>
</table>


For information about credit counseling services, call 1-877-337-8188.

www.citicards.com
Customer Service 1-855-378-6467

TTY:711

PO Box 790046 ST. LOUIS, MO 63179-0046


<table>
<tr>
<td>Account Summary</td>
<td></td>
</tr>
<tr>
<td>Previous balance</td>
<td>$2,176.80</td>
</tr>
<tr>
<td>Payments</td>
<td>-$0.00</td>
</tr>
<tr>
<td>Credits</td>
<td>-$0.00</td>
</tr>
<tr>
<td>Purchases</td>
<td>+$0.00</td>
</tr>
<tr>
<td>Cash advances</td>
<td>+ $0.00</td>
</tr>
<tr>
<td>Fees</td>
<td>+$0.00</td>
</tr>
<tr>
<td>Interest</td>
<td>+ $33.09</td>
</tr>
<tr>
<td>New balance</td>
<td>$2,209.89</td>
</tr>
<tr>
<td>Credit Limit</td>
<td></td>
</tr>
<tr>
<td>Credit Limit</td>
<td>$4,000</td>
</tr>
<tr>
<td colspan="2">Includes $1,200.00 cash advance limit</td>
</tr>
</table>


For Payments, send check to: Citi Cards, PO BOX 78019, Phoenix, AZ, 85062-8019

000000 NC 32 A 0
JOSHUA ANDERSON
16653 OLDHAM PL
ENCINO CA 91436-3707

Pay your bill from virtually anywhere
with the Citi Mobile App and Citi® Online
atI


<figure>
</figure>


To download:
Text 'App15' to MyCiti (692484)
or go to your device's app store.
Or visit www.citicards.com


<table>
<tr>
<td>Minimum payment due</td>
<td>$2,209.89</td>
</tr>
<tr>
<td>New balance</td>
<td>$2,209.89</td>
</tr>
<tr>
<td>Payment due date</td>
<td>11/22/22</td>
</tr>
</table>


Amount enclosed:
Account number ending in 0080
Please make check payable to Citi Cards.

Citi Cards
PO BOX 78019
Phoenix, AZ 85062-8019

<!-- PageBreak -->

