information and/or personal identifying information is omitted or redacted as required by local
rules, and applicable state and federal laws.

<!-- PageFooter="DECLARATION IN SUPPORT OF APPLICATION FOR ENTRY OF DEFAULT JUDGMENT (CIVIL CODE § 1788.60(a))" -->
<!-- PageNumber="4" -->

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28

<!-- PageBreak -->

