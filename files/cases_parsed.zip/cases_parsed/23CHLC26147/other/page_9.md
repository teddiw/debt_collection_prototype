Purchase Date:1/26/2023

1229

Data Excerpt from Exhibit 1 **


<table>
<tr>
<th>Field Name</th>
<th>Data Provided</th>
</tr>
<tr>
<td>ACCOUNT NUMBER</td>
<td>0080</td>
</tr>
<tr>
<td>SALE AMOUNT</td>
<td>$2,209.89</td>
</tr>
<tr>
<td>ACCOUNT OPEN DATE</td>
<td>12-Jul-16</td>
</tr>
<tr>
<td>CHARGE OFF DATE</td>
<td>22-Nov-22</td>
</tr>
<tr>
<td>LAST PAYMENT DATE</td>
<td>21-Apr-22</td>
</tr>
<tr>
<td>CONSUMER FIRST AND MIDDLE NAME</td>
<td>JOSHUA</td>
</tr>
<tr>
<td>CONSUMER LAST NAME</td>
<td>ANDERSON</td>
</tr>
<tr>
<td>CONSUMER RESIDENCE ADDRESS 1</td>
<td>16653 OLDHAM PL</td>
</tr>
<tr>
<td>CONSUMER RESIDENCE ADDRESS 2</td>
<td></td>
</tr>
<tr>
<td>CONSUMER RESIDENCE CITY</td>
<td>ENCINO</td>
</tr>
<tr>
<td>CONSUMER STATE</td>
<td>CA</td>
</tr>
<tr>
<td>CONSUMER ZIP CODE</td>
<td>914363707</td>
</tr>
<tr>
<td>CONSUMER SSN OR SIN*</td>
<td></td>
</tr>
</table>

*Data displayed has been redacted for consumer privacy

** The data contained in this document was extracted from the electronic records transmitted by the seller
concerning the referenced account


<!-- PageBreak -->

