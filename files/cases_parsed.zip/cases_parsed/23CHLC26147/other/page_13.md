EXHIBIT C

<!-- PageBreak -->

