Christopher D. Mandarich SB 220693
Teona Pipia SB 343337
Hayk Stambultsyan SB 320973
Martin Weingarten SB 201906
MANDARICH LAW GROUP, LLP
P.O. Box 109032Chicago, IL 60610
Phone: 877.285.4918
Facsimile: 818.888.1260
Attorneys for Plaintiff: CAVALRY SPV I, LLC, AS ASSIGNEE OF CITIBANK, N.A.

Electronically FILED by
Superior Court of California,
County of Los Angeles
10/02/2023 12:00 AM
David W. Slayton,
Executive Officer/Clerk of Court,
By E. Flores, Deputy Clerk


# SUPERIOR COURT OF CALIFORNIA IN AND FOR THE COUNTY OF LOS ANGELES

CAVALRY SPV I, LLC, AS ASSIGNEE OF
)
CITIBANK, N.A.,
Plaintiff,
)
)
VS.
)
)
)

JOSHUA ANDERSON, an individual;
and DOES 1 through 10 inclusive.
)
Defendant
)

Case No .:
23CHLC26147

DECLARATION OF VENUE

I, the undersigned attorney of record, hereby declare as follows:

1\.
I am an attorney licensed to practice before all courts of the State of California,
and I am one of the attorneys of record for the Plaintiff. The declaration is made of my own
knowledge and if sworn as a witness, I would and could testify thereto.

2\.
This is the proper venue, superior court and court location for this action because
a defendant herein resides in this court's jurisdiction.

I declare under penalty of perjury under the laws of the State of California that the
foregoing is true and correct.

Executed on September 27, 2023 in Los Angeles, California.

MANDARICH LAW GROUP, LLP


<figure>

J Juger

</figure>


[X]
☒
[] Teona Pipia, Esq.

<!-- PageFooter="DECLARATION OF VENUE" -->

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
