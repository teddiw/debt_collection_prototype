that portion of the charge off balance that remains due and owing as of August 16,
2024.

d. The last payment posted to the Account on April 21, 2022.

e. The charge-off creditor name and address at the time of charge off: CITIBANK,
N.A. PO BOX 78019 PHOENIX AZ 85062-8019.

f. The charge-off Account number associated with the debt at time of charge off was
Account No. ending in XXXXXXXXXXXX0080.

g. Defendant's name and last known address as it appeared in the charge off
creditor's records: JOSHUA ANDERSON 16653 OLDHAM PL , ENCINO, CA
91436-3707.

h. The names and addresses of all persons or entities that purchased the debt after
charge off, including the plaintiff debt buyer, are as follows:

i. CAVALRY SPV I, LLC, 1 American Lane Suite 220, Greenwich, CT 06831.
Prior to January 1, 2022, the address for CAVALRY SPV I, LLC was: 500
Summit Lake Drive, Suite 400, Valhalla, NY 10595.

9\.
CPS records maintained on behalf of Plaintiff state that Plaintiff, CPS or its
agents made demand for payment of the balance herein prior to making this declaration and
Defendant(s) failed to make full payment of the amount owed on the Account.

10\. Attached hereto as Exhibits A, B, and C are the account records I have reviewed
in executing the declaration that relate to the Account and/or payment(s) received.

Exhibit A. Seller Data document and Chain of Title - establishing the facts
required under Civil Code sections 1788.58(a)(3), (a)(7), and (a)(8).

Exhibit B. Account Statements and/or Account records including, but not limited
to, the most recent monthly statement recording a purchase transaction, last payment, or
balance transfer - establishing the fact required under Civil Code section 1788.52(b) and
1788.58(a)(5).

Exhibit C. Account Statement - establishing the facts required under Civil Code
sections 1788.58(a)(4), and (a)(6).

11\.
The documents attached hereto are true and correct copies of documents provided
to CPS on behalf of Plaintiff, by the original creditor, being a reproduction of the records on file
on behalf of Plaintiff based upon my review, except to the extent that confidential and privileged

DECLARATION IN SUPPORT OF APPLICATION FOR ENTRY OF DEFAULT JUDGMENT (CIVIL CODE § 1788.60(a)

<!-- PageNumber="3" -->

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28.

<!-- PageBreak -->

