<!-- PageHeader="Contract ID: CV8MUMAA122922 Addendum ID: CV8MUMAA122922C1 Document ID: 011723CVICCIFMBI" -->


# BILL OF SALE AND ASSIGNMENT Costco Fresh Flow Accounts

THIS BILL OF SALE AND ASSIGNMENT dated January 26, 2023, is by Citibank, N.A., a
national banking association organized under the laws of the United States, located at 5800 South
Corporate Place, Sioux Falls, SD 57108 (the "Bank") to Cavalry SPV I, LLC, organized under the
laws of Delaware, with its headquarters/principal place of business at 1 American Lane, Suite 220,
Greenwich, CT 06831 ("Buyer").

For value received and subject to the terms and conditions of the Master Purchase and Sale
Agreement dated December 29, 2022 and Addendum No. 1 dated December 29, 2022, between
Buyer and the Bank (the "Agreement"), the Bank does hereby transfer, sell, assign, convey, grant,
bargain, set over and deliver to Buyer, and to Buyer's successors and assigns, the Accounts
described in Exhibit 1 to the Addendum and the final electronic file.

Citibank, N.A.

By:

(Signature)

Name:
Terri Bergman

Title:
Authorized Party

<!-- PageFooter="Cavalry 122922" -->
<!-- PageNumber="1" -->
<!-- PageBreak -->

