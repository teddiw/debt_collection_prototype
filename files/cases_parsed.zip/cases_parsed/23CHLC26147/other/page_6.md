EXHIBIT A

<!-- PageBreak -->

