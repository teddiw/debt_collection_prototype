<!-- PageHeader="932957" -->

i. Plaintiff has complied with Civil Code §1788.52.

8\.
Based upon the information provided in the ordinary course of business to the
Plaintiff, the business records for this Account, attached hereto as Exhibit 2, reflect that the account
remains unpaid and the balance due and owing to Plaintiff as of 11/07/2024 is $9553.13.


<table>
<tr>
<td>Principal as of 10/04/2022:</td>
<td>$ 9,236.78</td>
</tr>
<tr>
<td>Costs:</td>
<td>$ 316.35</td>
</tr>
<tr>
<td>Payments made:</td>
<td>$ 0.00</td>
</tr>
<tr>
<td>TOTAL DUE:</td>
<td>$9,553.13</td>
</tr>
</table>


9\.
Despite repeated demands, no payments have been made on the Account since
06/30/2022.

I declare under penalty of perjury under the laws of the State of California that the foregoing is
true and correct.

Date: 12/05/2024

Holly Lees

Name:

Aly Les

\* 0 932957 - - - - AFF 1 - - - - -- 1 - *

<!-- PageNumber="- 3 -" -->
<!-- PageFooter="Declaration in Support of Entry of Default Judgment" -->

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28

<!-- PageBreak -->

