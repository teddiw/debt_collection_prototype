
<figure>

CapitalOne

</figure>


<figure>

Walmart ***

</figure>


<!-- PageNumber="Página 2 de 4" -->

Capital One Walmart Rewards® Card | World Mastercard que termina en 1165
sep 04, 2022 - oct 03, 2022 | 30 días en el Ciclo de Facturación


## Transacciones

Visite Walmart capitalone.com, para ver las transacciones detalladas.

LINO VILLANEDA #1165: Pagos, Créditos y Ajustes


<table>
<tr>
<th>Fecha de</th>
<th>Fecha de</th>
<th>Descripción</th>
<th>Cantidad</th>
</tr>
<tr>
<td>Transacción</td>
<td>Registro</td>
<td></td>
<td></td>
</tr>
</table>


LINO VILLANEDA #1165: Transacciones


<table>
<tr>
<th>Fecha de</th>
<th>Fecha de</th>
<th>Descripción</th>
</tr>
<tr>
<th>Transacción</th>
<th>Registro</th>
<th></th>
</tr>
</table>


Cantidad

Cargos y Cuotas


<table>
<tr>
<th>Fecha de Transacción</th>
<th>Fecha de Registro</th>
<th>Descripción</th>
<th>Cantidad</th>
</tr>
<tr>
<td colspan="2">Total de Cargos para Este</td>
<td>Período</td>
<td>$0.00</td>
</tr>
</table>


<table>
<tr>
<th></th>
<th colspan="2">Intereses Cobrados</th>
</tr>
<tr>
<td>Cargo por Intereses en Compras</td>
<td></td>
<td>$194.49</td>
</tr>
<tr>
<td>Cargo por Intereses sobre Adelantos de Dinero en Efectivo</td>
<td></td>
<td>$0.00</td>
</tr>
<tr>
<td>Cargo por Intereses sobre Dinero en Efectivo Rápido</td>
<td></td>
<td>$0.00</td>
</tr>
<tr>
<td>Cargo por Intereses en Otros Saldos</td>
<td></td>
<td>$0.00</td>
</tr>
<tr>
<td>Total de Intereses para Este Período</td>
<td></td>
<td>$194.49</td>
</tr>
<tr>
<td colspan="3">Totales del Año a la Fecha</td>
</tr>
<tr>
<td>Total de Cargos cobrados</td>
<td></td>
<td>$195.00</td>
</tr>
<tr>
<td>Total de Intereses cobrados</td>
<td></td>
<td>$1,661.57</td>
</tr>
</table>


## Cálculo de Cargos por Intereses

Su Tasa de Interés Anual (APR) es la tasa de interés anual de su cuenta.


<table>
<tr>
<th>Tipo de Saldo</th>
<th>Tasa de Interés Anual (APR)</th>
<th>Saldo Sujeto a Tasa de Interés</th>
<th>Intereses Cobrados</th>
</tr>
<tr>
<td>Compras</td>
<td>25.90% D</td>
<td>$9,135.94</td>
<td>$194.49</td>
</tr>
<tr>
<td>Adelantos de Dinero en Efectivo</td>
<td>28.90% D</td>
<td>$0.00</td>
<td>$0.00</td>
</tr>
</table>


APR Variables: Si usted tiene un código en letras que aparece junto a cualquiera de las APR mencionadas arriba, esto significa que son APR variables.
Puede que aumenten o disminuyan con base en uno de los siguientes índices (que se publican en el diario The Wall Street Journal) según se describe a
continuación.


<table>
<tr>
<th>Código al lado de su(s) APR</th>
<th>¿Cómo calculamos su(s) APR?</th>
<th>Cuándo cambiará(n) su(s) APR</th>
</tr>
<tr>
<td>P L</td>
<td>Tasa Preferencial (Prime) + margen Tasa LIBOR (Tasa Interbancaria de Londres) de 3 meses + margen</td>
<td>El primer día de los Ciclos de Facturación que terminan en enero, abril, julio y octubre.</td>
</tr>
<tr>
<td>D F</td>
<td>Tasa Preferencial (Prime) + margen Tasa LIBOR (Tasa Interbancaria de Londres) de 1 mes + margen</td>
<td>El primer día de cada Ciclo de Facturación</td>
</tr>
</table>


<!-- PageBreak -->

