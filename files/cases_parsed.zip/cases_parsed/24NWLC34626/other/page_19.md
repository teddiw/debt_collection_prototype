
<figure>

CapitalOne

</figure>


<figure>

Walmart >>

</figure>


<!-- PageNumber="Page 3 of 4" -->

Capital One Walmart Rewards® Card | World Mastercard ending in 1165
Sep 04, 2022 - Oct 03, 2022 | 30 days in Billing Cycle


## Payment Information

Payment Due Date

PAST DUE

For online and phone payments, the
deadline is 8pm ET.


<table>
<tr>
<th>New Balance</th>
<th>Minimum Payment Due</th>
</tr>
<tr>
<td>$9,236.78</td>
<td>$9,236.78</td>
</tr>
</table>


IMPORTANT: Your account has charged off and is now serviced by the
Recoveries department at 1-800-258-9319. Your full balance is due. Any
payment you make will reduce your balance and help pay off your debt
faster. The amount you owe may differ if you've entered into a separate
payment agreement.


<table>
<tr>
<td colspan="2">Account Summary</td>
</tr>
<tr>
<td colspan="2">Previous Balance $9,042.29</td>
</tr>
<tr>
<td>Payments</td>
<td>$0.00</td>
</tr>
<tr>
<td>Other Credits</td>
<td>$0.00</td>
</tr>
<tr>
<td>Transactions</td>
<td>+ $0.00</td>
</tr>
<tr>
<td>Quick Cash</td>
<td>+ $0.00</td>
</tr>
<tr>
<td>Cash Advances</td>
<td>+ $0.00</td>
</tr>
<tr>
<td>Fees Charged</td>
<td>+ $0.00</td>
</tr>
<tr>
<td>Interest Charged</td>
<td>+ $194.49</td>
</tr>
<tr>
<td>New Balance</td>
<td>= $9,236.78</td>
</tr>
<tr>
<td>Available Credit (as of Oct 03, 2022)</td>
<td>N/A</td>
</tr>
</table>


# Account Notifications

1
Welcome to your account notifications. Check back here each month for important updates about your account.

Pay or manage your account at Walmart.capitalone.com

Customer Service: 1-877-860-1250

See reverse for Important Information

<!-- PageBreak -->

