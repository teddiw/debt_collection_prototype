
<figure>

CapitalOne

</figure>


<figure>

Walmart >>

</figure>


<!-- PageNumber="Page 4 of 6" -->

Capital One Walmart Rewards® Card | World Mastercard ending in 1165
Jun 04, 2022 - Jul 03, 2022 1 30 days in Billing Cycle


## Payment Information


<table>
<tr>
<th>Payment Due Date Jul 28, 2022</th>
<th>For online and phone payments, the deadline is 8pm ET.</th>
</tr>
<tr>
<th>New Balance</th>
<th>Minimum Payment Due</th>
</tr>
<tr>
<td>$8,669.79</td>
<td>$1,229.00</td>
</tr>
</table>


LATE PAYMENT WARNING: If we do not receive your minimum payment
by your due date, you may have to pay a late fee of up to $39.00.

MINIMUM PAYMENT WARNING: If you make only the minimum
payment each period, you will pay more in interest and it will take you
longer to pay off your balance. For example:


<table>
<tr>
<th>If you make no additional charges using this card and each month you pay ...</th>
<th>You will pay off the balance shown on this statement in about</th>
<th>And you will end up paying an estimated total of</th>
</tr>
<tr>
<td>Minimum Payment</td>
<td>23 Years</td>
<td>$23,237</td>
</tr>
</table>


If you would like information about credit counseling services, call 1-888-326-8055.


<table>
<tr>
<td colspan="2">Account Summary</td>
</tr>
<tr>
<td>Previous Balance</td>
<td>$8,595.98</td>
</tr>
<tr>
<td>Payments</td>
<td>- $100.00</td>
</tr>
<tr>
<td>Other Credits</td>
<td>$0.00</td>
</tr>
<tr>
<td>Transactions</td>
<td>+ $0.00</td>
</tr>
<tr>
<td>Quick Cash</td>
<td>+ $0.00</td>
</tr>
<tr>
<td>Cash Advances</td>
<td>+ $0.00</td>
</tr>
<tr>
<td>Fees Charged</td>
<td>+ $0.00</td>
</tr>
<tr>
<td>Interest Charged</td>
<td>+ $173.81</td>
</tr>
<tr>
<td>New Balance</td>
<td>= $8,669.79</td>
</tr>
<tr>
<td>Credit Limit</td>
<td>$8,000.00</td>
</tr>
<tr>
<td>Available Credit (as of Jul 03, 2022)</td>
<td>$0.00</td>
</tr>
<tr>
<td>Cash Advance/Quick Cash Credit Limit</td>
<td>$1,600.00</td>
</tr>
<tr>
<td>Available Credit for Cash Advances/Quick Cash</td>
<td>$0.00</td>
</tr>
</table>


<figure>

!

Your account is suspended,
but you can get back on track.
Visit capitalone.com to make a payment
and see your payment options.

300082

Once paid, your card may be usable, depending on account status.

</figure>


Account Notifications
Please check page 6 of this statement for your Account Notifications.

Pay or manage your account at Walmart.capitalone.com

Customer Service: 1-877-860-1250

See reverse for Important information

Save time, stay informed.
Discover new features with:
the Capital One Mobile app.

Scan this QR Code with your phone's camera to download the
top-rated Capital One Mobile app.

<!-- PageBreak -->

