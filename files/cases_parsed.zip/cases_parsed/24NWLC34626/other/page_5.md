
# Excerpt from Sale File Assigned to Jefferson Capital Systems LLC Pursuant to the bill of sale dated 2022-11-16


<table>
<tr>
<th>Name</th>
<th>Social Security Number</th>
<th>Account Number</th>
<th>Seller Account Number</th>
<th>Open Date</th>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>LINO VILLANEDA</td>
<td>XXX-XX-8653</td>
<td>XXXXXXXXXXXX1165</td>
<td>XXXXXXXXXXXX7603</td>
<td>10/14/2015</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
</table>


LEGEND:

[Redacted] indicates that all data for these records is redacted to protect other Consumers who were included in the same sale file but not part of the current action. Social
Security Number, Account Number, and Seller Account Number information is masked to present only the last four characters in order to protect Consumer information.

<!-- PageFooter="JCAP Reference # : 3662420809" -->
<!-- PageNumber="Page 1 of 3" -->
<!-- PageFooter="Purchased Pool Reference ID: DELQ 1122 CAP1 202211" -->
<!-- PageBreak -->

