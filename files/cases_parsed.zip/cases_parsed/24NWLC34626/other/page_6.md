
# Excerpt from Sale File Assigned to Jefferson Capital Systems LLC Pursuant to the bill of sale dated 2022-11-16


<table>
<tr>
<th>Charge Off Date</th>
<th>Charge Off Amount</th>
<th>Purchased Balance</th>
<th>Last Payment Date</th>
<th>Last Payment Amount</th>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>10/04/2022</td>
<td>$9,236.78</td>
<td>$9,236.78</td>
<td>6/30/2022</td>
<td>$100.00</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
</table>


LEGEND:

[Redacted] indicates that all data for these records is redacted to protect other Consumers who were included in the same sale file but not part of the current action. Social
Security Number, Account Number, and Seller Account Number information is masked to present only the last four characters in order to protect Consumer information.

<!-- PageFooter="JCAP Reference # : 3662420809" -->
<!-- PageNumber="Page 2 of 3" -->
<!-- PageFooter="Purchased Pool Reference ID: DELQ 1122 CAP1 202211" -->
<!-- PageBreak -->

