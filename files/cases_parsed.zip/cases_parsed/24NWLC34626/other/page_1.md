<!-- PageHeader="932957" -->

John Goodman CA Bar #147569
P.O. Box 17210
Golden, CO 80402
PH: 877-328-6180
Fax: 303-215-1351

Electronically FILED by
Superior Court of California,
County of Los Angeles
12/05/2024 10:48 AM
David W. Slayton,
Executive Officer/Clerk of Court,
By Y. Garcia, Deputy Clerk

Attorney for
JEFFERSON CAPITAL SYSTEMS, LLC


# SUPERIOR COURT OF THE STATE OF CALIFORNIA FOR THE COUNTY OF LOS ANGELES

Jefferson Capital Systems, LLC
Plaintiff(s),

Case No .: 24NWLC34626

VS.

DECLARATION IN SUPPORT OF ENTRY
OF DEFAULT JUDGMENT (CCP §585
DEC)

LINO VILLANEDA, an individual.

)

Defendant.

)
)
)
)
)

I, the undersigned, declare:

1\.
I have personal, first-hand knowledge of the matter set forth herein, if called as a
witness, could and would testify to the following:

2\.
I am the Records Custodian for Jefferson Capital Systems, LLC, ("the Plaintiff") and
am authorized to make this Declaration on behalf of the Plaintiff.

3\.
The following statements and representations are based upon my personal review
and knowledge of the books and records of the Plaintiff, which contain information provided to the
Plaintiff.

4\.
In the performance of my duties for Plaintiff, I am familiar with the record keeping
systems, which include the account of the Defendant, Lino Villaneda. Records maintained by the

<!-- PageNumber="- 1 -" -->
<!-- PageFooter="Declaration in Support of Entry of Default Judgment" -->

1
2
3
4
5
6
7
8
9
10
11
12

13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28

<!-- PageBreak -->

