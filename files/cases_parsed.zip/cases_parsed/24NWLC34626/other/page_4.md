
# Master Account Sale Agreement dated June 7, 2021 Account Sale Addendum dated April 28, 2022

932957


## BILL OF SALE

Closing Date: November 16,2022

Capital One, N.A. ("Seller"), in consideration of a Purchase Price of
and other good and
valuable consideration, the receipt and sufficiency of which is hereby acknowledged, hereby sells, assigns, conveys,
sets over, and transfers all right, title and interest in the Accounts identified in the Sale File entitled

OMEGA,BN0033.SALES.PROD-EAST.PWFRLE20221110_BN0033_customer.dat.gz
OMEGA.BN0033.SALES.PROD-EAST.PWFRLE20221110_BN0033_main.dat.gz
OMEGA.BN0033.SALES.PROD-EAST.PWFRLE20221110_BN0033_phone.dat.gz

(which may be in electronic form) to Jefferson Capital Systems, LLC ("Buyer"), and including all proceeds thereof of
any kind, without recourse or representation except as expressly provided herein or on the terms, and subject to the
conditions, set forth in the Agreement (as defined below).

This Bill of Sale is delivered pursuant to and in accordance with the terms of that certain Master Account Sale
Agreement, dated as of June 7, 2021, by and between Seller and Buyer (as amended, restated or otherwise modified
from time to time, the "Agreement"). All capitalized terms used, but not defined, in this Bill of Sale shall have the
meanings assigned to such terms in the Agreement. This Bill of Sale does not amend the terms of the Agreement in
any respect. The representations, warranties, covenants, agreements and indemnities contained in the Agreement
shall not be superseded hereby but shall remain in full force and effect as and to the extent provided in the Agreement.

The Cutoff Date for the Sale File was November 10, 2022. The aggregate Sale Balance of the Accounts as
of the Cutoff Date was

IN WITNESS WHEREOF, Seller, by its duly authorized representative, has executed and delivered this Bill of Sale as
of the date first above written.


<figure>

CAPITAL ONE, NATIONAL ASSOCIATION
By:
Mimo

</figure>


Name: Wesley Perkins
Title: Managing Vice President

<!-- PageBreak -->

