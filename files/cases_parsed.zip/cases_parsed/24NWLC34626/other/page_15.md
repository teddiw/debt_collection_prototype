
<figure>

CapitalOne

</figure>


<figure>

Walmart >>

</figure>


<!-- PageNumber="Page 6 of 6" -->

Capital One Walmart Rewards® Card ! World Mastercard ending in 1165
Jun 04, 2022 - Jul 03, 2022 1 30 days in Billing Cycle


## Account Notifications

0
☐
For questions about this account, please give us a call at 1-800-955-6600. We'll be glad to help you Monday through Friday from 8 a.m. to 11 p.m.
ET, and Saturday and Sunday from 8 a.m. to 5 p.m. ET.

☐
1
Your account has gone over its credit limit and is currently past due.

1
☐
Your minimum payment was not received in time to avoid a late fee. As a courtesy, we didn't charge you a late fee this month. Please note that we may
charge a late fee in future months if we don't receive at least your minimum payment by your due date.

<!-- PageBreak -->

