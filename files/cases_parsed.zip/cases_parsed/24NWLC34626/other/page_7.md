
# Excerpt from Sale File Assigned to Jefferson Capital Systems LLC Pursuant to the bill of sale dated 2022-11-16


<table>
<tr>
<th>Co Borrower Name</th>
<th>Original Creditor</th>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted] CAPITAL ONE NATIONAL ASSOCIATION</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
<tr>
<td>[Redacted]</td>
<td>[Redacted]</td>
</tr>
</table>


LEGEND:

[Redacted] indicates that all data for these records is redacted to protect other Consumers who were included in the same sale file but not part of the current action. Social
Security Number, Account Number, and Seller Account Number information is masked to present only the last four characters in order to protect Consumer information.

<!-- PageFooter="JCAP Reference # : 3662420809" -->
<!-- PageNumber="Page 3 of 3" -->
<!-- PageFooter="Purchased Pool Reference ID: DELQ 1122 CAP1 202211" -->
<!-- PageBreak -->

