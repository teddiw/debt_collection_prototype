
<figure>

CapitalOne

</figure>


<figure>

Walmart ?

</figure>


<!-- PageNumber="Página 3 de 6" -->

Capital One Walmart Rewards® Card | World Mastercard que termina en 1165
jun 04, 2022 - jul 03, 2022 | 30 días en el Ciclo de Facturación


## Notificaciones sobre la Cuenta

Si usted tiene preguntas sobre esta cuenta, por favor llámenos al 1-800-955-6600. Será un placer ayudarle de lunes a viernes de 8 a.m. a 11 p.m.,
Hora del Este, y sábados y domingos de 8 a.m. a 5 p.m., Hora del Este.

0
Su cuenta ha sobrepasado el límite de crédito y en este momento está atrasada en el pago.

0
Su pago mínimo no se recibió a tiempo para evitar un cargo por atraso en el pago. Como cortesía, no le hemos cobrado cargos por atraso en el pago
este mes. Por favor tenga presente que podemos cobrar cargos por atraso en el pago en los próximos meses si no recibimos al menos su pago mínimo
a más tardar en la fecha de vencimiento.

<!-- PageBreak -->

