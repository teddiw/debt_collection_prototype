
<figure>

CapitalOne

</figure>


<figure>

Walmart

</figure>


<!-- PageNumber="Página 1 de 4" -->

Capital One Walmart Rewards® Card | World Mastercard que termina en 1165
sep 04, 2022 - oct 03, 2022 | 30 días en el Ciclo de Facturación

Información de Pago


<table>
<tr>
<th>Fecha de Vencimiento del Pago PAGO VENCIDO</th>
<th>Para pagos por Internet y por teléfono, la hora límite es a las 8 pm, Hora del Este.</th>
</tr>
<tr>
<th>Saldo Nuevo</th>
<th>Pago Mínimo a Pagar</th>
</tr>
<tr>
<td>$9,236.78</td>
<td>$9,236.78</td>
</tr>
</table>


IMPORTANTE: Su cuenta ha sido declarada como pérdida y ahora es
administrada por el departamento de Recuperación de Fondos en el
1-800-258-9319. Debe la totalidad de su saldo. Cualquier pago que
usted haga reducirá su saldo y le ayudará a pagar su deuda más rápido.
La cantidad que usted debe podría variar si ha llegado a un acuerdo de
pago separado.


<table>
<tr>
<td colspan="2">Resumen de la Cuenta</td>
</tr>
<tr>
<td>Saldo Anterior</td>
<td>$9,042.29</td>
</tr>
<tr>
<td>Pagos</td>
<td>$0.00</td>
</tr>
<tr>
<td>Otros Créditos</td>
<td>$0.00</td>
</tr>
<tr>
<td>Transacciones</td>
<td>+ $0.00</td>
</tr>
<tr>
<td>Dinero en Efectivo Rápido</td>
<td>+ $0.00</td>
</tr>
<tr>
<td>Adelantos de Dinero en Efectivo</td>
<td>+ $0.00</td>
</tr>
<tr>
<td>Cargos Cobrados</td>
<td>+ $0.00</td>
</tr>
<tr>
<td>Intereses Cobrados</td>
<td>+ $194.49</td>
</tr>
<tr>
<td>Saldo Nuevo</td>
<td>= $9,236.78</td>
</tr>
<tr>
<td>Crédito Disponible (a oct 03, 2022)</td>
<td>NO APLICA (N/A)</td>
</tr>
</table>


Notificaciones sobre la Cuenta

0
Bienvenido(a) a las notificaciones sobre su cuenta. Revise aquí todos los meses para ver avisos importantes sobre su cuenta.

Pague o administre su cuenta en Walmart.capitalone.com (en inglés)

Servicio al Cliente: 1-877-860-1250
Consulte la Información Importante al reverso


<figure>

CapitalOne

</figure>


<figure>

Walmart ®

</figure>


LINO VILLANEDA
14919 FIRMONA AVE
LAWNDALE, CA 90260-1244

Fecha de Vencimiento del Pago: Pago Vencido

Cuenta que termina en 1165


<table>
<tr>
<th>Saldo Nuevo</th>
<th>Pago Mínimo a Pagar</th>
<th>Cantidad Adjunta</th>
</tr>
<tr>
<td>$9,236.78</td>
<td>$9,236.78</td>
<td>$</td>
</tr>
</table>


Por favor envíenos esta porción de su estado de cuenta y un solo cheque (o giro postal) pagadero a Capital
One para asegurar que su pago sea tramitado rápidamente. La entrega por correo postal puede tomar al
menos siete días laborales.

Capital One
P.O. Box 60519
City of Industry CA 91716-0519

<!-- PageBreak -->

