
<figure>

CapitalOne

</figure>


<figure>

Walmart

</figure>


<!-- PageNumber="Page 4 of 4" -->
<!-- PageHeader="Capital One Walmart Rewards® Card | World Mastercard ending in 1165 Sep 04, 2022 - Oct 03, 2022 | 30 days in Billing Cycle" -->


## Transactions

Visit Walmart.capitalone.com to see detailed transactions.


### LINO VILLANEDA #1165: Payments, Credits and Adjustments


<table>
<tr>
<th>Trans Date</th>
<th>Post Date</th>
<th>Description</th>
<th>Amount</th>
</tr>
<tr>
<td colspan="3">LINO VILLANEDA # 1165: Transactions</td>
<td></td>
</tr>
<tr>
<td>Trans Date</td>
<td>Post Date</td>
<td>Description</td>
<td>Amount</td>
</tr>
</table>


<table>
<tr>
<th></th>
<th></th>
<th></th>
<th>Fees</th>
<th></th>
</tr>
<tr>
<th>Trans Date</th>
<th>Post Date</th>
<th>Description</th>
<th></th>
<th>Amount</th>
</tr>
<tr>
<td colspan="2">Total Fees for This Period</td>
<td></td>
<td></td>
<td>$0.00</td>
</tr>
<tr>
<td colspan="2"></td>
<td colspan="2">Interest Charged</td>
<td></td>
</tr>
<tr>
<td colspan="2">Interest Charge on Purchases</td>
<td></td>
<td></td>
<td>$194.49</td>
</tr>
<tr>
<td colspan="2">Interest Charge on Cash Advances</td>
<td></td>
<td></td>
<td>$0.00</td>
</tr>
<tr>
<td colspan="2">Interest Charge on Quick Cash</td>
<td></td>
<td></td>
<td>$0.00</td>
</tr>
<tr>
<td colspan="2">Interest Charge on Other Balances</td>
<td></td>
<td></td>
<td>$0.00</td>
</tr>
<tr>
<td colspan="2">Total Interest for This Period</td>
<td></td>
<td></td>
<td>$194.49</td>
</tr>
<tr>
<td colspan="2"></td>
<td colspan="2">Totals Year-to-Date</td>
<td></td>
</tr>
<tr>
<td colspan="2">Total Fees charged</td>
<td></td>
<td></td>
<td>$195.00</td>
</tr>
<tr>
<td colspan="2">Total Interest charged</td>
<td></td>
<td></td>
<td>$1,661.57</td>
</tr>
</table>


## Interest Charge Calculation

Your Annual Percentage Rate (APR) is the annual interest rate on your account.


<table>
<tr>
<th>Type of Balance</th>
<th>Annual Percentage Rate (APR)</th>
<th>Balance Subject to Interest Rate</th>
<th>Interest Charged</th>
</tr>
<tr>
<td>Purchases</td>
<td>25.90% D</td>
<td>$9,135.94</td>
<td>$194.49</td>
</tr>
<tr>
<td>Cash Advances</td>
<td>28.90% D</td>
<td>$0.00</td>
<td>$0.00</td>
</tr>
</table>


Variable APRs: If you have a letter code displayed next to any of the above APRs, this means they are variable APRs. They may increase or decrease based
on one of the following indices (reported in The Wall Street Journal) as described below.


<table>
<tr>
<th>Code next to your APR(s)</th>
<th>How do we calculate your APR(s)?</th>
<th>When your APR(s) will change</th>
</tr>
<tr>
<td rowspan="2">P L</td>
<td>Prime Rate + margin</td>
<td rowspan="2">The first day of the Billing Cycles that end in Jan., April, July and Oct.</td>
</tr>
<tr>
<td>3 month LIBOR + margin</td>
</tr>
<tr>
<td rowspan="2">D F</td>
<td>Prime Rate + margin</td>
<td rowspan="2">The first day of each Billing Cycle</td>
</tr>
<tr>
<td>1 month LIBOR + margin</td>
</tr>
</table>
