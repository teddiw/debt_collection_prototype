
<figure>

CapitalOne

</figure>


<figure>

Walmart

</figure>


<!-- PageNumber="Página 1 de 6" -->

Capital One Walmart Rewards® Card I World Mastercard que termina en 1165
jun 04, 2022 - jul 03, 2022 | 30 días en el Ciclo de Facturación


# Información de Pago


<table>
<tr>
<th>Fecha de Vencimiento del Pago jul 28, 2022</th>
<th>Para pagos por Internet y por teléfono, la hora límite es a las 8 pm, Hora del Este.</th>
</tr>
<tr>
<td>Saldo Nuevo</td>
<td>Pago Mínimo a Pagar</td>
</tr>
<tr>
<td>$8,669.79</td>
<td>$1,229.00</td>
</tr>
</table>


AVISO SOBRE ATRASO EN EL PAGO:Si no recibimos su pago mínimo a
más tardar en la fecha de vencimiento, es posible que tenga que pagar
un cargo por atraso en el pago de hasta $39.00.

AVISO SOBRE PAGO MÍNIMO: Si usted solo hace el pago mínimo en
cada período, pagará más en intereses y le tomará más tiempo pagar su
saldo en su totalidad. Por ejemplo:


<table>
<tr>
<td>Si no hace ningún cargo adicional con esta tarjeta y cada mes paga ...</td>
<td>Pagará el saldo total que aparece en este estado de cuenta en aproximadamente. ..</td>
<td>Y terminará pagando un total estimado de ...</td>
<td></td>
</tr>
<tr>
<td>Pago Mínimo</td>
<td>23 Años</td>
<td>$23,237</td>
<td></td>
</tr>
</table>


Si desea información sobre servicios de asesoría de crédito, llame al 1-888-326-8055.


# Resumen de la Cuenta


<table>
<tr>
<td>Saldo Anterior</td>
<td>$8,595.98</td>
</tr>
<tr>
<td>Pagos</td>
<td>- $100.00</td>
</tr>
<tr>
<td>Otros Créditos</td>
<td>$0.00</td>
</tr>
<tr>
<td>Transacciones</td>
<td>+ $0.00</td>
</tr>
<tr>
<td>Dinero en Efectivo Rápido</td>
<td>+ $0.00</td>
</tr>
<tr>
<td>Adelantos de Dinero en Efectivo</td>
<td>+ $0.00</td>
</tr>
<tr>
<td>Cargos Cobrados</td>
<td>+ $0.00</td>
</tr>
<tr>
<td>Intereses Cobrados</td>
<td>+ $173.81</td>
</tr>
<tr>
<td>Saldo Nuevo</td>
<td>= $8,669.79</td>
</tr>
<tr>
<td>Límite de Crédito</td>
<td>$8,000.00</td>
</tr>
<tr>
<td>Crédito Disponible (a jul 03, 2022)</td>
<td>$0.00</td>
</tr>
<tr>
<td>Límite de Crédito de Dinero en Efectivo Rápido/Adelanto de Dinero en Efectivo</td>
<td>$1,600.00</td>
</tr>
<tr>
<td>Crédito Disponible para Adelantos de Dinero en Efectivo/Dinero en Efectivo Rápido</td>
<td>$0.00</td>
</tr>
</table>


<figure>

!

Tu cuenta está suspendida
pero puedes ponerla al día.
Visita capitalone.com para ver opciones y hacer tu pago.

300082

Según el estado de tu cuenta, al pagar podrás seguir usando tu tarjeta.

</figure>


Notificaciones sobre la Cuenta

Por favor consulte la página 3 de este estado de cuenta para ver las Notificaciones sobre su Cuenta.

Pague o administre su cuenta en Walmart.capitalone.com (en inglés)

Servicio al Cliente: 1-877-860-1250
Consulte la Información Importante al reverso


<figure>

CapitalOne

</figure>


<figure>

Walmart

</figure>


LINO VILLANEDA
14919 FIRMONA AVE
LAWNDALE, CA 90260-1244

Fecha de Vencimiento del Pago: jul 28, 2022
Cuenta que termina en 1165


<table>
<tr>
<th>Saldo Nuevo</th>
<th>Pago Mínimo a Pagar</th>
<th>Cantidad Adjunta</th>
</tr>
<tr>
<td>$8,669.79</td>
<td>$1,229.00</td>
<td>$</td>
</tr>
</table>


Por favor envíenos esta porción de su estado de cuenta y un solo cheque (o giro postal) pagadero a Capital
One para asegurar que su pago sea tramitado rápidamente. La entrega por correo postal puede tomar al
menos siete días laborales.

Ahorra tiempo, mantente al
tanto. Mira nuevas funciones
con la app Móvil de Capital One.

Escanee este código QR con la cámara de su teléfono para descargar
la app Móvil de Capital One, reconocida como una de las mejores.

Capital One
P.O. Box 60519
City of Industry CA 91716-0519

<!-- PageBreak -->

