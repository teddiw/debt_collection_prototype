
<figure>

CapitalOne

</figure>


<figure>

Walmart

</figure>


<!-- PageNumber="Page 4 of 6" -->

Capital One Walmart Rewards® Card | World Mastercard ending in 1165
Jun 04, 2022 - Jul 03, 2022 | 30 days in Billing Cycle


# Payment Information


<table>
<tr>
<th>Payment Due Date Jul 28, 2022</th>
<th>For online and phone payments, the deadline is 8pm ET.</th>
</tr>
<tr>
<th>New Balance</th>
<th>Minimum Payment Due</th>
</tr>
<tr>
<td>$8,669.79</td>
<td>$1,229.00</td>
</tr>
</table>


LATE PAYMENT WARNING: If we do not receive your minimum payment
by your due date, you may have to pay a late fee of up to $39.00.

MINIMUM PAYMENT WARNING: If you make only the minimum
payment each period, you will pay more in interest and it will take you
longer to pay off your balance. For example:


<table>
<tr>
<td>If you make no additional charges using this card and each month you pay ...</td>
<td>You will pay off the balance shown on this statement in about ...</td>
<td>And you will end up paying an estimated total of ...</td>
</tr>
<tr>
<td>Minimum Payment</td>
<td>23 Years</td>
<td>$23,237</td>
</tr>
</table>


If you would like information about credit counseling services, call 1-888-326-8055.


# Account Summary

Previous Balance

$8,595.98

Payments

\- $100.00

Other Credits

$0.00

Transactions

\+ $0.00

Quick Cash

\+ $0.00

Cash Advances

\+ $0.00

Fees Charged

\+ $0.00

Interest Charged

\+ $173.81

New Balance
= $8,669.79

Credit Limit

$8,000.00

Available Credit (as of Jul 03, 2022)

$0.00

Cash Advance/Quick Cash Credit Limit

$1,600.00

Available Credit for Cash Advances/Quick
Cash
$0.00


<figure>

!

Your account is suspended,
but you can get back on track.

300082

Visit capitalone.com to make a payment
and see your payment options.

Once paid, your card may be usable, depending on account status.

</figure>


## Account Notifications Please check page 6 of this statement for your Account Notifications.

Pay or manage your account at Walmart.capitalone.com

Customer Service: 1-877-860-1250

See reverse for Important Information


<figure>

Save time, stay informed.
Discover new features with
the Capital One Mobile app.

B

Scan this QR Code with your phone's camera to download the
top-rated Capital One Mobile app.

</figure>


<!-- PageBreak -->

