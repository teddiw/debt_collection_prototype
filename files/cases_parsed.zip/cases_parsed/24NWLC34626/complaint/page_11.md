
<figure>

CapitalOne

</figure>


<figure>

Walmart

</figure>


<!-- PageNumber="Page 5 of 6" -->
<!-- PageHeader="Capital One Walmart Rewards® Card | World Mastercard ending in 1165 Jun 04, 2022 - Jul 03, 2022 | 30 days in Billing Cycle" -->


### Transactions

Visit Walmart.capitalone.com to see detailed transactions.

LINO VILLANEDA #1165: Payments, Credits and Adjustments


<table>
<tr>
<th>Trans Date</th>
<th>Post Date</th>
<th>Description</th>
<th>Amount</th>
</tr>
<tr>
<td>Jun 30</td>
<td>Jun 30</td>
<td>PAYMENT RECEIVED -- THANK YOU</td>
<td>- $100.00</td>
</tr>
</table>


LINO VILLANEDA #1165: Transactions

Trans Date

Post Date

Description

Amount


<table>
<tr>
<th></th>
<th></th>
<th colspan="2">Fees</th>
<th></th>
</tr>
<tr>
<th>Trans Date</th>
<th>Post Date</th>
<th>Description</th>
<th></th>
<th>Amount</th>
</tr>
<tr>
<td colspan="2">Total Fees for This Period</td>
<td></td>
<td></td>
<td>$0.00</td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td>Interest Charged</td>
<td></td>
</tr>
<tr>
<td colspan="2">Interest Charge on Purchases</td>
<td></td>
<td></td>
<td>$173.81</td>
</tr>
<tr>
<td colspan="2">Interest Charge on Cash Advances</td>
<td></td>
<td></td>
<td>$0.00</td>
</tr>
<tr>
<td colspan="2">Interest Charge on Quick Cash</td>
<td></td>
<td></td>
<td>$0.00</td>
</tr>
<tr>
<td colspan="2">Interest Charge on Other Balances</td>
<td></td>
<td></td>
<td>$0.00</td>
</tr>
<tr>
<td colspan="2">Total Interest for This Period</td>
<td></td>
<td></td>
<td>$173.81</td>
</tr>
<tr>
<td colspan="2"></td>
<td></td>
<td>Totals Year-to-Date</td>
<td></td>
</tr>
<tr>
<td colspan="2">Total Fees charged</td>
<td></td>
<td></td>
<td>$195.00</td>
</tr>
<tr>
<td colspan="2">Total Interest charged</td>
<td></td>
<td></td>
<td>$1,094.58</td>
</tr>
</table>


### Interest Charge Calculation

Your Annual Percentage Rate (APR) is the annual interest rate on your account.


<table>
<tr>
<th>Type of Balance</th>
<th>Annual Percentage Rate (APR)</th>
<th>Balance Subject to Interest Rate</th>
<th>Interest Charged</th>
</tr>
<tr>
<td>Purchases</td>
<td>24.40% D</td>
<td>$8,666.47</td>
<td>$173.81</td>
</tr>
<tr>
<td>Cash Advances</td>
<td>27.40% D</td>
<td>$0.00</td>
<td>$0.00</td>
</tr>
</table>


Variable APRs: If you have a letter code displayed next to any of the above APRs, this means they are variable APRs. They may increase or decrease based
on one of the following indices (reported in The Wall Street Journal) as described below.


<table>
<tr>
<th>Code next to your APR(s)</th>
<th>How do we calculate your APR(s)?</th>
<th>When your APR(s) will change</th>
</tr>
<tr>
<td rowspan="2">P L</td>
<td>Prime Rate + margin</td>
<td rowspan="2">The first day of the Billing Cycles that end in Jan., April, July and Oct.</td>
</tr>
<tr>
<td>3 month LIBOR + margin</td>
</tr>
<tr>
<td>D F</td>
<td>Prime Rate + margin 1 month LIBOR + margin</td>
<td>The first day of each Billing Cycle</td>
</tr>
</table>


<!-- PageFooter="Additional Information on the next page" -->
<!-- PageBreak -->

