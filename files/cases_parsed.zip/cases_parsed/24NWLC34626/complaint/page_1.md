<!-- PageHeader="932957" -->
<!-- PageHeader="PLD-C-001" -->


<table>
<tr>
<th>ATTORNEY OR PARTY WITHOUT ATTORNEY (Name, State Bar number, and address): Attorney First Last John Goodman State Bar Number: 147569 P.O. Box 17210 Golden, CO 80402 TELEPHONE NO: 877-328-6180 FAX NO. 303-215-1351 E-MAIL ADDRESS: Courtdocs@JCap.com ATTORNEY FOR (Name): Jefferson Capital Systems, LLC</th>
<th rowspan="2">FOR COURT USE ONLY Electronically FILED by Superior Court of California, County of Los Angeles 8/13/2024 10:48 AM David W. Slayton, Executive Officer/Clerk of Court, By J. Mascarenhas, Deputy Clerk</th>
</tr>
<tr>
<td>SUPERIOR COURT OF CALIFORNIA, COUNTY OF LOS ANGELES STREET ADDRESS: 12720 Norwalk Blvd. MAILING ADDRESS: CITY AND ZIP CODE: Norwalk, CA 90650 BRANCH NAME:Los Angeles- Norwalk Courthouse</td>
</tr>
<tr>
<td>PLAINTIFF: JEFFERSON CAPITAL SYSTEMS, LLC DEFENDANT: LINO VILLANEDA</td>
<td></td>
</tr>
<tr>
<td>[ ] DOES 1 to</td>
<td rowspan="3"></td>
</tr>
<tr>
<td>CONTRACT</td>
</tr>
<tr>
<td>[ X ] COMPLAINT ☒ [ ] AMENDED COMPLAINT (Number): ]</td>
</tr>
<tr>
<td>[ ] CROSS-COMPLAINT [ ] AMENDED CROSS-COMPLAINT(Number):</td>
<td></td>
</tr>
<tr>
<td>Jurisdiction (check all that apply): [ X ☒ I ACTION IS A LIMITED CIVIL CASE Amount demanded [ X] does not exceed $10,000 ☒ [ ] exceeds $10,0000, but does not exceed $25,000 [] ACTION IS AN UNLIMITED CIVIL CASE (exceeds $25,000) [ ] ACTION IS RECLASSIFIED by this amended complaint or cross-complaint</td>
<td rowspan="2">CASE NUMBER: 24NWLC34626</td>
</tr>
<tr>
<td>[ ] from limited to unlimited [ ] from unlimited to limited</td>
</tr>
</table>


1\. Plaintiff* (name or names): Jefferson Capital Systems, LLC

alleges causes of action against defendant* (name or names): LINO VILLANEDA

2\. This pleading, including attachments and exhibits, consists of the following number of pages:

3\. a. Each plaintiff named above is a competent adult

[ X ] except plaintiff (name): Jefferson Capital Systems, LLC
☒

(1)
[

]
I a corporation qualified to do business in California

(2)
[

]
an unincorporated entity (describe):

(3)
[

☒
] Other (specify): A Limited Liability Company qualified to do business in California

b. [ ] Plaintiff (name):

a.
] has complied with the fictitious business name laws and is doing business under the fictitious name (specify):
[

b.
] has complied with all licensing requirements as a licensed (specify):
[

[

C.
] Information about additional plaintiffs who are not competent adults is shown in Attachment 3c.

4\. a. Each defendant named above is a natural person

[
] except defendant (name):

(1)
a business organization, form unknown
]
[

(2) [
]
a corporation

(3)
[

]
an unincorporated entity (describe):

(4) [ ] a public entity (describe):

(5)
1
other (specify):
[

[
] except defendant (name):

(1)
) [ ] a business organization, form unknown

(2) [ ] a corporation

(3)

[
]
an unincorporated entity (describe):

(4) [
] a public entity (describe):
(5)
5) [ ] other (specify):

*If this form is used as a cross-complaint, plaintiff means cross-complainant and defendant means cross-defendant.

<!-- PageNumber="Page 1 of 2" -->
<!-- PageFooter="Form Approved for Optional Use Judicial Council of California PLD-C-001 [ Rev. January 1, 2007]" -->
<!-- PageFooter="COMPLAINT - Contract" -->
<!-- PageFooter="Code of civ. Proc., §425.12" -->
<!-- PageBreak -->

