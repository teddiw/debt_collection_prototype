might include court costs and necessary disbursements allowed by
C.C.P. § 1033 (b) (2).


# FIRST CAUSE OF ACTION (Account Stated)

13\. Plaintiff repeats and repleads and incorporates by
reference the allegations made in Paragraphs I through 12 of this
complaint.

14\. The balance due at charge off was $15,264.86. After
deduction for all post charge off offsets and credits, if any, there
is now due, owing and unpaid from Defendant to Plaintiff the current
balance of $15, 264.86, and upon information and belief there is
$0.00 in post charge-off fees and $0.00 in post charge-off interest.
15\. Defendants were indebted to the charge-off creditor,
WebBank, as issuer of the loan account, in the amount of $15, 264.86
on an account stated in writing. Please see the payment history
reflecting the indebtedness attached hereto as Exhibit B. This
WebBank loan account was for credit purchases and/or cash advances.
Defendant was billed monthly and failed to dispute as required under
the Federal Fair Billing Act applicable to such account (15 U.S.C. $
1666 et seq.) .

16\. The date of last payment made on the account was June 24,
2019\.

17\. Prior to filing this complaint, all right, title and
interest in the account which is the subject of this lawsuit,
Account Number XXXXX8730, was sold and assigned by WebBank as issuer

<!-- PageNumber="4" -->
<!-- PageFooter="Complaint" -->

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28

<!-- PageBreak -->

