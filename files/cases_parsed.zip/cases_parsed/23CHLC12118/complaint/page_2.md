and in accordance with the provisions of Section 474 of the Code of
Civil Procedure. Plaintiff will ask leave of court to amend this
complaint as and when the true names and capacities of Defendants
named herein as DOES 1 to 10 have been ascertained.

2\. At all times herein mentioned, Defendants, and each of
them, were the agents, servants and employees of each other and
every remaining Defendant, and in doing the things alleged, were
acting in the course and scope of said authority of such agents,
servants, and employees.

3\. Plaintiff is now and was at all times herein mentioned a
limited liability company, authorized to do business in the State of
California.

4\. Plaintiff is a debt buyer as defined by Section 1788.50 of
the CA Civil Code. Plaintiff and Plaintiff's counsel's application
for license pursuant to Financial Code Section 100000 et. seq. are
pending issuance with the Nationwide Multistate Licensing and
Registry and/or the California Department of Financial Protection
and Innovation.

5\. Section 1788.50 of the CA Civil Code is applicable to this
action as the debt subject to this lawsuit was purchased by
Plaintiff after January 1, 2014. Plaintiff is the sole owner of the
debt at issue.

6\. Plaintiff is in compliance with Section 1788.52 of the CA
Civil Code. Attached hereto as Exhibit A is a true and correct copy

<!-- PageNumber="2" -->
<!-- PageFooter="Complaint" -->

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28

<!-- PageBreak -->

