24\. Neither the whole nor any part of the above charged-off
sum has been paid, although payment has been demanded, leaving a
balance due, owing and unpaid to Plaintiff in the amount of
$15, 264.86 together with costs of suit.

WHEREFORE, plaintiff prays for judgment against Defendants, and
each of them, jointly and severally, as follows:


# FOR THE FIRST CAUSE OF ACTION

(1) Damages in the sum $15,264.86;

(2) Costs of Suit and;

(3) Such other relief as the Court may deem just and proper.


# FOR THE SECOND CAUSE OF ACTION

(1) Damages in the sum $15,264.86;

(2) Costs of Suit and;

(3) Such other relief as the Court may deem just and proper.

NELSON & KENNARD

Dated: May 1, 2023

kl

By :

Kristen Dean

Attorney for Plaintiff

<!-- PageNumber="6" -->
<!-- PageFooter="Complaint" -->

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28

<!-- PageBreak -->

