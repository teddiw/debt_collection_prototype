<!-- PageHeader="VERIFICATION" -->

I, Kristen Dean, declare:

1\. I am an attorney at law duly admitted and licensed to
practice before all courts of the State of California and I have my
professional offices at 5011 Dudley Blvd., Bldg. 250, Bay G,
Mcclellan, Sacramento County, California.

2\. I am the attorney of record for Plaintiff in the above-
entitled matter. Said Plaintiff is absent from the county in which
I have my office and for that reason, I am making this verification
on its behalf.

3\. I have read the foregoing Complaint and know the content
thereof. Venue lies properly with this court because Defendant
either resides in this judicial district at the time this action is
commenced, or the contract was in fact signed by the Defendant in
this judicial district.

4\. As to all other matters, I am informed and believe that
the matters stated therein are true and, on that ground, I allege
the matters stated therein are true.

I declare under penalty of perjury of the laws of the State of
California that the foregoing is true and correct.

Executed at Mcclellan, California.

Dated: May 1, 2023

Ke

Kristen Dean

<!-- PageFooter="VERIFICATION" -->
<!-- PageNumber="1" -->

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28

<!-- PageBreak -->

