of the loan account, to LVNV FUNDING LLC. LVNV FUNDING LLC is the
sole owner of the debt at issue.

18\. Plaintiff made demand on defendants for payment of that
sum, but no part of that sum has been paid to plaintiff, and the
entire amount is now due and unpaid.

19\. Neither the whole nor any part of the above charged-off
sum has been paid, although payment has been demanded, leaving a
balance due, owing and unpaid to Plaintiff in the amount of
$15, 264.86 and together with costs of suit.


# SECOND CAUSE OF ACTION (Money Lent)

20\. Plaintiff repeats and repleads and incorporates by
reference the allegations made in Paragraphs 1 through 20 of this
complaint.

21\. The balance due at charge off was $15,264.86. After
deduction for all post charge off offsets and credits, if any, there
is now due, owing and unpaid from Defendant to Plaintiff the current
balance of 15,264.86.

22\. Within the last four years, Defendant became indebted to
the charge-off creditor, WebBank, loan account, in the amount of
$15, 264.86 for money lent to or paid out for the benefit of
Defendant at his/her request, based on Defendant's use and benefit
of his/her account.

23\. The date of last payment made on the account was June 24,
2019\.

<!-- PageNumber="5" -->
<!-- PageFooter="Complaint" -->

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28

<!-- PageBreak -->

