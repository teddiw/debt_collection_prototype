1
2
3
4
5

File No. 23-07350-0
Robert Scott Kennard
State Bar No. 117017
Kristen Dean
State Bar No. 321178
NELSON & KENNARD
5011 Dudley Blvd., Bldg. 250, Bay G
Mcclellan, CA 95652-1020
P.O. Box 13807
Sacramento, CA 95853
Telephone: (916) 920-2295
Facsimile: (916) 920-0682

Electronically FILED by
Superior Court of California,
County of Los Angeles
5/05/2023 9:12 AM
David W. Slayton,
Executive Officer/Clerk of Court,
By I. Baytalyants, Deputy Clerk

Attorneys for Plaintiff
LVNV FUNDING LLC as assignee of WebBank

SUPERIOR COURT OF CALIFORNIA, COUNTY OF LOS ANGELES
NORTH VALLEY DISTRICT-CHATSWORTH-LIMITED CIVIL CASE

LVNV FUNDING LLC as assignee of
WebBank

Plaintiff,

VS.

JESSE ALBA
and DOES 1 to 10, Inclusive,
Defendants.

CASE NO. 23CHLC12118
COMPLAINT FOR ACCOUNT STATED;
MONEY LENT

(DEMAND AMOUNT: $15,264.86)

Plaintiff alleges and complains as follows:


# PRELIMINARY ALLEGATIONS

Plaintiff, LVNV FUNDING LLC, as assignee of WebBank, as issuer
of the loan account, complains of Defendants, and each of them,
singularly and collectively, that:

1\. The true names and capacities of Defendants herein sued by
the fictitious names as DOES 1 to 10, Inclusive, are unknown to
Plaintiff, who therefore sues those Defendants under, pursuant to,

<!-- PageFooter="Complaint" -->
<!-- PageNumber="1" -->

6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28

<!-- PageBreak -->

