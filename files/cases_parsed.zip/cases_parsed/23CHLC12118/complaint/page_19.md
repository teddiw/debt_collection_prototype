<!-- PageHeader="This is a copy of an authoritative document" -->

Joint marketing

A formal agreement between nonaffiliated financial companies that
together market financial products or services to you.

· Our joint marketing partners include financial services
companies, lenders, insurance companies, or other consumer
service providers.


### COPY OF


# AUTHORITATIVE


<figure>

DOCUMENT

</figure>


<!-- PageFooter="The authoritative document is maintained by LendingClub Corporation and this copy was created Oct 17 2018 01:53:29" -->
<!-- PageBreak -->

