of a promissory note, which demonstrates that the debt was incurred
by the Defendant.

7\. The nature of the underlying debt is a credit agreement
entered into between the charge-off creditor and the Defendant. The
Defendant obtained credit to use for the purchase of certain goods
and services and used the account for that purpose.

8\. The name of the charge-off creditor is WebBank, as issuer
of the loan account. The address of the charge-off creditor at the
time of charge-off was 215 SOUTH STATE STREET SUITE 1000 SALT LAKE
CITY, UT 84111. The last four digits of the charge-off account
number are XXXXX8730.

9\. The name and last known address of the Defendant as they
appeared in the charged-off creditor's records prior to the sale of
the debt was JESSE ALBA, 4007 BATRIS CT CALABASAS, CA 91302.

10\. The name and address of all entities that purchased the
debt after charge-off is/are: LVNV FUNDING LLC, 355 S Main Street,
Suite 300-D Greenville, SC 29601.

11\. Plaintiff is informed and believes and thereon alleges
that Defendant JESSE ALBA is an individual who resides in the City
of Woodland Hills, County of Los Angeles, State of California.

12\. Before commencement of this action, in those cases where
recovery of costs is dependent on such notices, Plaintiff informed
the Defendant (s) in writing that it intended to file this action and
that this action may result in a judgment against Defendant (s) that

<!-- PageNumber="3" -->
<!-- PageFooter="Complaint" -->

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28

<!-- PageBreak -->

