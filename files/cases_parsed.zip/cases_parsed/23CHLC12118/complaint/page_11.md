<!-- PageHeader="This is a copy of an authoritative document" -->

misleading or deceptive statements or omissions of fact in your listing, including but not limited to your loan description; (ii) misrepresent
your identity, or describe, present or portray yourself as a person other than yourself; (iii) give to or receive from, or offer or agree to give to
or receive from any LendingClub member or other person any fee, bonus, additional interest, kickback or thing of value of any kind except in
accordance with the terms of your loan; (iv) represent yourself to any person, as a representative, employee, or agent of ours, or purport to
speak to any person on our behalf; (v) use any of the loan proceeds to fund any post-secondary educational expenses, including, but not
limited to, tuition, fees, books, supplies, miscellaneous expenses, or room and board; or (vi) use any of the loan proceeds to fund any illegal
activity or any other activity or use not otherwise allowed under this Agreement or the Site; (vii) use any of the loan proceeds for the purpose
of purchasing or carrying any securities; (viii) use any of the loan proceeds for the purpose of investing, trading, or speculating in any
currencies, including without limitation cryptocurrencies or digital currencies or any futures or derivatives thereof; or (ix) use the Site to
request or obtain a loan for someone other than yourself, and (C) that you have all necessary consents, permissions, acknowledgements or
agreements from all joint applicants/co-borrowers and we may rely upon this agreement without any investigation or verification. You further
acknowledge and agree that we may rely without independent verification on the accuracy, authenticity, and completeness of all information
you provide to us. To the extent that we determine, in our sole discretion, that your loan request violates this Agreement the Terms of Use
or any other agreement entered into with us or LendingClub, we may terminate your loan request and cancel this Agreement immediately.

11\. Liability of the Borrower and Joint Applicant/CoBorrower is Joint and Several. The liability of any joint applicant/co-borrower
under this Agreement and under the Loan Agreement and Promissory Note is in addition to and not in lieu of the obligations of the primary
borrower. The joint applicant co-borrower agrees to abide by the terms and conditions of this Agreement, the Loan Agreement and
Promissory Note and any other agreement and documents as if an original signatory.

We and our successors and assigns have sole discretion to proceed, at any time, against any party responsible under this Agreement.
Further, we can accept instructions from either you or the joint applicant/co-borrower, and notice can be given to either you or the joint
applicant/co-borrower, and shall be binding on both and deemed received by all parties.


<figure>

12\. TCPA Consent & Privacy. Notwithstanding any current or prior election to opt in or opt out of receiving telemarketing calls or SMS
messages (including text messages) from us, our agents, representatives, affiliates, or anyone calling on our behalf, you expressly consent
to be contacted by us, our agents, representatives, affiliates, or anyone calling on our behalf for any and all purposes arising out of or
relating to your Ican and/or account, at any telephone number, or physical or electronic address you provide or at which you may be
reached. You agree we may contact you In any way, including SIM$ messages (including text messages), calls using prerecorded messages
or artificial voice, and calls and messages delivered using auto telephone dialing system or an automatic texting system, Automated
messages may be played when the telephone is answered whether by you or someone else. In the event that an agent or representative
calls, he or she may also leave a message on your answering machine, voice mail, or send one via tekt.

</figure>


You consent to receive SMS messages (including text messages), calls and messages (including prerecorded and artificial voice and
autodialed) from us, our agents, representatives, affiliates or anyone calling on our behalf at the specific number(s) you have provided to us,
or numbers we can reasonably associate with your account (through skip trace, caller ID capture or other means), with information or
questions about your application, loan and/or account. You certify, warrant and represent that the telephone numbers that you have
provided to us are your contact numbers. You represent that you are permitted to receive calls at each of the telephone numbers you have
provided to us. You agree to promptly alert us whenever you stop using a particular telephone number.

DOCUMENT

Your cellular or mobile telephone provider will charge you according to the type of plan you carry. You also agree that we may contact you by
e-mail, using any email address you have provided to us or that you provide to us in the future. We may listen to and/or record phone calls
between you and our representatives without notice to you as permitted by applicable law. For example, we listen to and record calls for
quality monitoring purposes.

13\. Assignment; Registration of Note Owners, Termination. We may assign this Agreement and the Loan Agreement and Promissory
Note, or any of our rights under this Agreement or the Loan Agreement and Promissory Note, in whole or in part at any time. You further
understand, acknowledge and agree that LendingClub or another third party may further sell, assign or transfer your Loan Agreement and
Promissory Note and all associated documents and information related to the and the Loan Agreement and Promissory Note without your
consent or notice to you (subject to the registration requirement below). You may not assign, transfer, sublicense or otherwise delegate
your rights or obligations under this Agreement to another person without our prior written consent. Any such assignment, transfer,
sublicense or delegation in violation of this section 13 shall be null and void.

You hereby appoint LendingClub as your agent (in such capacity, the "Note Registrar") for the purpose of maintaining a book-entry system
(the "Register") for recording the names and addresses of any owner of beneficial interests in this Note (the "Note Owners") and the
principal amounts and interest on this Note owing to each pursuant to the terms hereof from time to time. The person or persons identified
as the Note Owners in the Register shall be treated as the owner(s) of this Note for purposes of receiving payment of principal and interest
on such Note and for all other purposes. With respect to any transfer by a Note Owner of its beneficial interest in this Note, the right to
payment of principal and interest on this Note shall not be effective until the transfer is recorded in the Register.

We may terminate this Agreement and your ability to make loan requests at any time. If you committed fraud or made a misrepresentation in
connection with your registration on the Site or any application or request for a loan, performed any prohibited activity, or otherwise failed to
abide by the terms of this Agreement, we will have all remedies authorized or permitted by this Agreement and applicable law.

<!-- PageFooter="The authoritative document is maintained by LendingClub Corporation and this copy was created Oct 17 2018 01:53:29" -->
<!-- PageBreak -->

