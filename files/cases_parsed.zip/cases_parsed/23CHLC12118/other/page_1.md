File No. 23-07350-0

Robert Scott Kennard

State Bar No. 117017

Christopher Danna

State Bar No. 337998

NELSON & KENNARD

Street Address :

5011 Dudley Blvd., Bldg. 250, Bay G

Mcclellan, CA 95652

Electronically FILED by
Superior Court of California,
County of Los Angeles
6/06/2024 1:22 AM
David W. Slayton,
Executive Officer/Clerk of Court,
By M. Bell, Deputy Clerk

Mailing Address:

P.O. Box 13807

Sacramento, CA 95853

Telephone :

(916) 920-2295

Facsimile:

(916) 920-0682

Email: Nk-efile@nelson-kennard.com

Attorneys for Plaintiff
LVNV FUNDING LLC

SUPERIOR COURT OF CALIFORNIA, COUNTY OF LOS ANGELES
NORTH VALLEY DISTRICT-CHATSWORTH-LIMITED CIVIL CASE

LVNV FUNDING LLC,

)
)

Case No. : 23CHLC12118

Plaintiff,

VS.
JESSE ALBA,
Defendant.
)
)

)
DECLARATION IN OPPOSITION TO

)
ORDER TO SHOW CAUSE

)


<table>
<tr>
<td>)</td>
<td>DATE :</td>
<td>6/18/2024</td>
</tr>
<tr>
<td>)</td>
<td>TIME :</td>
<td>8:30 AM</td>
</tr>
<tr>
<td>)</td>
<td>DEPT :</td>
<td>F41</td>
</tr>
</table>


I, Christopher Danna, hereby declare:

1\. I am an attorney at law duly licensed to practice before
all courts of the State of California and am an associate employed
by the law office of Nelson & Kennard, Attorneys for Plaintiff LVNV
FUNDING LLC (hereinafter "Plaintiff") . As to each of the matters
set forth herein, I testify of my own personal knowledge except as
to those matters of which I testify on information or belief and/or
upon my personal review of the records for the Law Offices of
Nelson & Kennard (hereinafter "Nelson & Kennard") .
1

DECLARATION IN OPPOSITION TO ORDER TO SHOW CAUSE

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28

<!-- PageBreak -->

