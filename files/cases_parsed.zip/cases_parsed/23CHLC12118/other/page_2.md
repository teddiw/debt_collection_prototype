2\. I am familiar with the manner and method of record
keeping at Nelson & Kennard. Each of the records referenced herein
are kept in the ordinary course of business as a standard business
practice of Nelson & Kennard. If called to testify, I would
competently affirm the content hereof.

3\. Plaintiff filed its complaint against Defendant (s) JESSE
ALBA on May 5, 2023 to recover the balance owing on a defaulted
agreement. Service of process was effected on May 26, 2023.

4\. Plaintiff anticipates submitting its Default Judgement
Application prior to the next scheduled hearing.

5\. Plaintiff respectfully requests this Court vacate the
Order to Show Cause hearing, or alternatively continue this hearing
for 30 to 60 days, to allow time for the court to consider
Plaintiff's Default Judgement Application.

I declare under penalty of perjury under the laws of the State
of California that the foregoing is true and correct, and that this
declaration was executed on
6/3/2024
at Mcclellan, County of
Sacramento, California.

CHRISTOPHER DANNA

<!-- PageNumber="2" -->
<!-- PageFooter="DECLARATION IN OPPOSITION TO ORDER TO SHOW CAUSE" -->

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28

<!-- PageBreak -->

