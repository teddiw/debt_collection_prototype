
# PROOF OF SERVICE

State of California
County of Sacramento

)
)

I am a resident of the County aforesaid; I am over the age of
eighteen years and not a party to the within action; my business
address is 5011 Dudley Blvd., Bldg. 250, Bay G, Mcclellan,
California 98652.

On

06/04/2024

,

I served the within:

DECLARATION IN OPPOSITION TO ORDER TO SHOW CAUSE

on the parties in said action by placing a true and correct copy
thereof in a sealed envelope and addressed as set forth below.

I served the documents described hereinabove by placing said
documents for collection and processing for mailing following this
business's ordinary practice with which I am readily familiar. On
the same day correspondence is placed for collection and mailing,
it is deposited in the ordinary course of business with the United
States Postal Service.

I declare under penalty of perjury under the laws of the State
of California that the foregoing is true and correct, and that this
declaration was executed on
06/04/2024
at Mcclellan,
California.

Lale Mant

Karla Gant

JESSE ALBA
22375 MOREA WAY
WOODLAND HILLS, CA 91367-7238

<!-- PageNumber="1" -->
<!-- PageFooter="PROOF OF SERVICE" -->

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
