
# BILL OF SALE

For value received and pursuant to the terms and conditions of the Purchase and
Sale Agreement dated April 3, 2018, MPLI Capital Holdings, as "Initial
Seller", and on behalf of Additional Sellers as "Servicer") hereby assigns
effective as of January 27, 2022 (the "Closing Date") all rights, title and interest
in and to those certain charged-off loans and all related receivables, judgments
or evidences of debt described in Schedule I attached hereto and made part
hereof for all purposes to Velocity Investments, LLC ("Purchaser").

UPSTART NETWORK, INC., as [INITIAL SELLER] [SERVICER] on
behalf of MPLI Capital Holdings

By:
Sanjay Datta
Date: 1/25/2022

Title:

CFO


<figure>

80

</figure>


<figure>

Loan id

Purchase Price

</figure>


<!-- PageBreak -->

