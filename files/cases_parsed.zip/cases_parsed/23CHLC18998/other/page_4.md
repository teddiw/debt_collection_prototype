
<table>
<tr>
<td>Account Balance Sued Upon</td>
<td>$3,116.30</td>
</tr>
<tr>
<td>Court Costs Incurred</td>
<td>$249.00</td>
</tr>
<tr>
<td>Less Post-Suit Payment Credits</td>
<td>$.00</td>
</tr>
<tr>
<td>TOTAL</td>
<td>$3,365.30</td>
</tr>
</table>


I declare under penalty of perjury under the laws of the State of California that the foregoing is
true and correct.

12/5/2023

at 1800 ROUTE 34 N, BLDG 3 STE 305, WALL NJ 07719.

Executed on

By:

Maressa Stabile

Compliance Associate

<!-- PageNumber="4" -->
<!-- PageFooter="DECLARATION IN SUPPORT OF APPLICATION FOR ENTRY OF DEFAULT JUDGMENT PURSUANT TO CIVIL CODE §1788.60" -->

1
2
3
4
5
6
7
8
9
10
11
12

13
14
15
16
17
18
19
20
21
22
23
24
25

26
27
28

<!-- PageBreak -->

