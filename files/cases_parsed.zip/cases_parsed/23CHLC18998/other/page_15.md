<!-- PageHeader="File TP123037" -->

EXHIBIT "B"

<!-- PageBreak -->

