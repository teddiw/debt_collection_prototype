to recover only that portion of the charge-off balance that remains due and owing.

d.
The date of last payment is July 29, 2021.

e.
The charge-off creditor was MPLI CAPITAL HOLDINGS ISSUED BY FINWISE BANK
SERVICED BY UPSTART NETWORK INC, 71 STEVENSON STREET SUITE 300 SAN
FRANCISCO CA 94105.

f.
The charge-off Account number associated with the debt at time of charge-off was ***** 8068.

g.
Defendant(s) name and last known address as it appeared in the charge-off creditor's records was
PAUL FERNANDEZ, 216 W MARKLAND DR, MONTEREY PARK CA 91754.

h.
The complete chain of title, including MPLI CAPITAL HOLDINGS ISSUED BY FINWISE
BANK SERVICED BY UPSTART NETWORK INC, 71 STEVENSON STREET SUITE 300
SAN FRANCISCO CA 94105, and all post charge-off purchasers of the debt are as follows:


<table>
<tr>
<th>Name</th>
<th>Address</th>
</tr>
<tr>
<td>MPLI CAPITAL HOLDINGS</td>
<td>71 STEVENSON STREET SUITE 300 SAN</td>
</tr>
<tr>
<td>ISSUED BY FINWISE BANK</td>
<td>FRANCISCO CA 94105</td>
</tr>
<tr>
<td>SERVICED BY UPSTART</td>
<td>1800 ROUTE 34 NORTH, WALL, NJ 07719</td>
</tr>
</table>


NETWORK INC
VELOCITY INVESTMENTS LLC

10\. Attached hereto collectively as Exhibit "B" are true and correct copies of said transfers and are
incorporated herein by reference. Plaintiff hereby requests that the Court accept copies of the exhibits
attached hereto in lieu of originals.

11\. Demand has been made on Defendant(s), and each of them, for the payment of said sum owed
of $3,116.30. Defendant(s) failed to make full payment of the amount owed on the Account. Attached
hereto as Exhibit "C" is a true and correct copy of the payment history.

12\. Plaintiff hereby requests that the Court accept copies of the exhibits attached hereto in lieu of
originals.

13\. Plaintiff has incurred court costs of $249.00 to date.

14\. Plaintiff therefore requests a money judgment against Defendant(s) as follows:

<!-- PageNumber="3" -->
<!-- PageFooter="DECLARATION IN SUPPORT OF APPLICATION FOR ENTRY OF DEFAULT JUDGMENT PURSUANT TO CIVIL CODE §1788.60" -->

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28

<!-- PageBreak -->

