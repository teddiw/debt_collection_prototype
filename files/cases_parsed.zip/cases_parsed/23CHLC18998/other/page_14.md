<!-- PageHeader="DocuSign Envelope ID: DBA6052C-CD13-4FDA-828F-BB02701140B7" -->
<!-- PageHeader="Copy of the Electronic Original® document managed by the eCore® On Demand (EOD™) Service." -->

unenforceable or inapplicable in New Jersey.

For Utah residents: As required by Utah law, you are hereby notified that a negative credit report reflecting
on your credit record may be submitted to a credit reporting agency if you fail to fulfill the terms of your
credit obligations.

For Utah residents: This written agreement is a final expression of the agreement between you and us and
the written agreement may not be contradicted by evidence of any alleged oral agreement.

For Married Wisconsin Residents: Wisconsin law provides that no provision of a marital property agreement,
unilateral statement under Section 766.59, Wisconsin Statutes, or a court decree under Section 766.70,
Wisconsin Statutes, affecting marital property adversely affects the interest of a creditor, unless the creditor
receives a copy of the agreement, statement or decree prior to granting the credit or unless the creditor has
actual knowledge of the adverse provision when the obligation to the creditor is incurred.

By signing this Note electronically, I acknowledge that I (i) have read and understand all terms and conditions
of this Note, (ii) agree to the terms set forth herein, and (illy acknowledge receipt of a completely filled-in copy
of this Note. You understand this Note is executed in, and loan proceeds are distributed from, Utah.

CAUTION - IT IS IMPORTANT THAT YOU READ THROUGH THE CONTRACT BEFORE YOU SIGN
IT.

NOTICE TO CUSTOMER: (1) DO NOT SIGN THIS IF IT CONTAINS ANY BLANK SPACES. (2) YOU
ARE ENTITLED TO AN EXACT COPY OF ANY AGREEMENT YOU SIGN. (3) YOU HAVE THE
RIGHT AT ANY TIME TO PAY IN ADVANCE THE UNPAID BALANCE DUE UNDER THIS
AGREEMENT.


<figure>

Date:
6/15/2021
DocuSignod byl
By:
$1035742FA75404.
(Signed Electronically)
Original

</figure>


<!-- PageFooter="Last Updated: August 11, 2020" -->
<!-- PageFooter="The original document is owned by Velocity Investments, LLC and this copy was created on May 03, 2022 02:55:13 PM." -->
<!-- PageBreak -->

