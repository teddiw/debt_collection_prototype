<!-- PageHeader="File TP123037" -->

EXHIBIT "C"

<!-- PageBreak -->

